package myTest;

//Anthony Fuller
//Chapter 42 Program 1
//Use JUnit to test java.lang.string

import static org.junit.Assert.*;

import org.junit.Test;

public class StringExamplesTest {
	public String myTest= "Nothing was entered";
	
	@Test
	public void test() {
		
		StringExamples ex =
				new StringExamples(myTest);
		assertTrue(ex.getLength() ==
				getLength());
		assertTrue(ex.getCharAt() ==
				getCharAt());
		assertTrue(ex.getSubstring() ==
				getSubstring());
		assertTrue(ex.getIndexOf() ==
				getIndexOf());
		assertTrue(ex.getConcact() ==
				getConcact());
		assertTrue(ex.getHashcode() ==
				getHashcode());
		assertTrue(ex.getTrim() ==
				getTrim());
		assertTrue(ex.getToUpperCase() ==
				getToUpperCase());
	}

	private String getToUpperCase() {
		return myTest.toUpperCase();
	}

	private String getTrim() {
		return myTest.trim();
	}

	private int getHashcode() {
		return myTest.hashCode();
	}

	private String getConcact() {
		return myTest.concat("e");
	}

	private int getIndexOf() {
		return myTest.indexOf(myTest);
	}

	private String getSubstring() {
		return myTest.substring(2, 3);
	}

	private char getCharAt() {
		return myTest.charAt(2);
	}

	private int getLength() {
		
		return myTest.length();
	}

}
