package myTest;

//Anthony Fuller
//Chapter 42 Program 1
//Use JUnit to test java.lang.string

public class StringExamples {
	private String myTest;

	public StringExamples(){
		this("Nothing was entered");
	}
	public StringExamples(String theTest){
		this.myTest = theTest;
	}
	
	//All of these must be included
	public int getLength(){
		return myTest.length();
		
		
	}
	public char getCharAt(){
		return myTest.charAt(2);
		
	}
	public String getSubstring(){
		return myTest.substring(2, 3);
		
	}
	public int getIndexOf(){
		return myTest.indexOf(myTest);
		
	}
	//4 methods chosen
	public String getConcact(){
		return myTest.concat("e");
		
	}
	public int getHashcode(){
		return myTest.hashCode();
		
	}
	public String getTrim(){
		return myTest.trim();
		
	}
	public String getToUpperCase(){
		return myTest.toUpperCase();
		
	}
}
