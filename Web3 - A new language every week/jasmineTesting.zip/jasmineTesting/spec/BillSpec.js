/*
US currency bills are 2.61 inches wide, 6.14 inches long, .0043 inches thick
*/
describe("Bill",function(){
    describe("one dollar",function(){
        var dollarBill;

        beforeEach(function(){
            dollarBill = new Bill(1);
        });
    
        it('should have a value of one',function(){
            expect(dollarBill.value()).toEqual(1);
        });
        it('should accept the string one',function(){
            dollarBill = new Bill('one');
            expect(dollarBill.value()).toEqual(1);
        });
        it('should have the dimensions 2.61x6.14x.0043',function(){
            expect(dollarBill.dimension).toEqual({length:2.61,width:6.14,height:.0043});
        });
        it('should calculate the value of n bills',function(){
            expect(dollarBill.valueOfNumberOfBills(200)).toEqual(200);
        });
    });

    describe("five dollar",function(){
        var fiveBill;

        beforeEach(function(){
            fiveBill = new Bill(5);
        });
    
        it('should have a value of five',function(){
            expect(fiveBill.value()).toEqual(5);
        });
    });
});