/* standard pallet is 40 inches wide x 48 inches long */
describe("Pallet",function(){
    var pallet;
    beforeEach(function(){
        pallet = new Pallet();
    });

    it("should have a width of 40",function(){
        expect(pallet.width).toEqual(40);
    });
    it("should have a length of 40",function(){
        expect(pallet.length).toEqual(48);
    });
    it("should fit 1920 1x1 items",function(){
        var item = {length:1,width:1};
        expect(pallet.holdsHowMany(item)).toEqual(1920);
    });
    it("should stack 23040 12 inches height",function(){
        var item = {length:1,width:1,height:1};
        expect(pallet.stacksHowMany(item,12)).toEqual(23040);
    });
});