function Bill(moneyKey){
    var moneyMap = {
        1 : 1,
        'one' : 1,
        5 : 5
    }
    this.amount = moneyMap[moneyKey];
    this.dimension = {length:2.61,width:6.14,height:.0043};
}
Bill.prototype.value = function(){
    return this.amount;
}
Bill.prototype.valueOfNumberOfBills = function(numberOfBills){
    return this.value() * numberOfBills;
}