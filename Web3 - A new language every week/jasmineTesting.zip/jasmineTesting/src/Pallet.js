function Pallet(){
    this.width = 40;
    this.length = 48;
}
Pallet.prototype.holdsHowMany = function(item){
    var accrossLength = this.length / item.length;
    var accrossWidth = this.width / item.width;
    return accrossLength * accrossWidth;
}
Pallet.prototype.stacksHowMany = function(item, howHigh){
    var row = this.holdsHowMany(item);
    var height = howHigh / item.height;
    return row * height;
}