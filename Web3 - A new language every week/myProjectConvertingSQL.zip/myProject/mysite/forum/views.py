from django.shortcuts import render
#from django.http import HttpResponse
#from django.template import loader
from .models import User

# Create your views here.
def index(request):
    #template = loader.get_template('forum/index.html')
    #return HttpResponse("Forum index.")
    return render(request, 'forum/create_cat.html', {})

def signup(request):
    request.POST.get('user_name', None)
    return render(request, 'forum/signup.html', {})