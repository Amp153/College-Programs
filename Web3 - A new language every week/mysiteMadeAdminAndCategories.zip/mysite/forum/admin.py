from django.contrib import admin
from .models import Categories

admin.site.register(Categories)