const express = require('express');
const http = require('http');
const app = express();
const WebsocketChat = require('./websocket-chat.js');

app.use(express.static('public'));

const server = http.createServer(app);
const websocketChat = new WebsocketChat(server);

server.listen(8080,function(){
    console.log("Listening on port 8080");
});