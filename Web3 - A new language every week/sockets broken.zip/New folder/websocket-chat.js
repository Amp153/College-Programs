const Websocket = require('ws');
class WebsocketChat{
    constructor(server){
        this.wss = new Websocket.Server({server});

        this.wss.on('connection',(ws,req)=>this.connection(ws,req));
    }
    connection(ws,req){
        ws.on('message',(messageString)=>{
            this.broadcastOthers(ws,messageString);
        });
    }
    broadcastOthers(ws,data){
        this.wss.clients.forEach((client)=>{
            if(client !== ws && client.readyState === WebSocket.OPEN){
                client.send(data);
            }
        });
    }
}

module.exports = WebsocketChat;