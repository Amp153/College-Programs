let socketServerURI = "ws://localhost:8080";
let socket = new WebSocket(socketServerURI);
socket.addEventListener('open',function(event){
    socket.addEventListener('message',(message)=>{
        appendMessage(message.data);
    });
    document.querySelector("#send").addEventListener("click",()=>{
        let messageElement = document.querySelector('input[name="message"]');
        let message = messageElement.value;
        appendMessage(message);
        socket.send(message);
        messageElement.value = "";
    });
});