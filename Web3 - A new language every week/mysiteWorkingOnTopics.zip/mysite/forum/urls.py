from django.urls import path, include
from django.contrib.auth.views import login, logout

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('signup', views.signup, name='signup'),
    # whenever 'topic' is called by the {% url %} template tag
    path('<int:id>', views.topic, name='topic'),
    path('accounts/', include('django.contrib.auth.urls')),
]