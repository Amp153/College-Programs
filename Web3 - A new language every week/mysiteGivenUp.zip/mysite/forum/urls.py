from django.urls import path, include
from django.contrib.auth.views import login, logout

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('signup', views.signup, name='signup'),
    # whenever 'topic' is called by the {% url %} template tag
    path('topic/<int:category_id>', views.category_topic, name='topic'),
    #path('<int:pk>/topic', views.TopicView.as_view(), name='topic'),
    path('accounts/', include('django.contrib.auth.urls')),
]