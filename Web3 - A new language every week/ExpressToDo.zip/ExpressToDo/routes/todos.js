var express = require('express');
var router = express.Router();

let todos = [{name:"make express app",done:false}];

router.get('/',function(req,res){
    res.render('todos/index',{todos:todos});
});
router.post('/',function(req,res){
    if(req.body.todo){
        todos.push({name:req.body.todo,done:false});
    }res.redirect('/todos');
});

router.get('/entry',function(req,res){
    res.render('todos/entry');
})
router.get('/:id',function(req,res){
    var id = req.params.id;
    var todo = todos[id];
    if(!todo){
        res.send("id" + id + "not found");
    }
    res.render('todos/update',{todo:todo,id:id});
});
router.post('/:id',function(req,res){

    var todo = todos[req.params.id];
    if(!todo){
        res.send("id" + req.params.id + "not found");
    }
    if(req.body.method === "PUT"){
        todo.name = req.body.todo;
        todo.done = (req.body.done)? true : false;
    }
    if(req.body.method === "DELETE"){
        var index = todos.indexOf(todo);
        todos.splice(index,1);
    }
    res.redirect('/todos');
});

module.exports = router;