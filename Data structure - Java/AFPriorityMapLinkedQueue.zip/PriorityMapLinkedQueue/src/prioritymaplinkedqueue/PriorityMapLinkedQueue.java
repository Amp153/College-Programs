/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prioritymaplinkedqueue;


import java.util.*;
public class PriorityMapLinkedQueue<E>{

    public static void main(String args[]){
        PriorityMapLinkedQueue<String> pmlq = new PriorityMapLinkedQueue<>();
        pmlq.enqueue(0, "apple");
        pmlq.enqueue(1, "peach");
        pmlq.enqueue(0, "appricot");
        pmlq.enqueue(1, "pear");
        pmlq.enqueue(0, "acorn");
        pmlq.enqueue(1, "pen");
        
        for(int i = 0; i < pmlq.size();i++){
            System.out.println(pmlq.dequeue());
        }    
    }


    private HashMap<Integer, LinkedList<E>> priorityMap;
    private int size = 0;
    public PriorityMapLinkedQueue(){
        priorityMap = new HashMap<>();
    }
    public void enqueue(int priority, E e){
        LinkedList<E> elementList = priorityMap.get(priority);
        if(elementList == null){
            elementList = new LinkedList<E>();
            priorityMap.put(priority, elementList);
        }
        elementList.add(e);
        size++;
    }
    public E dequeue(){
        if(priorityMap.isEmpty()){
            return null;
        }else{
            //size--;
            return getHighestPriorityList().removeLast();
        }
    }
    public int size(){
        return size;
    }
    private List<Integer> getSortedPriorityList(){
        List<Integer> priorities = new ArrayList<>(priorityMap.keySet());
        //priorities = Collections.sort.priorities;
        Collections.sort(priorities);
        priorities = bubbleSort(priorities);
        return priorities;
    }
    private Integer getHighestPriority(){
        /* Call getSortedPriorityList and return the last element in the list */
        //getHighestPriorityList().getLast(); not the right answer
        return getSortedPriorityList().get(getSortedPriorityList().size()-1);
        //return getSortedPriorityList().get(1);
    }
    private LinkedList<E> getHighestPriorityList(){
        /*
        Retrieve the LinkedList from the priority map using the highestPriority variable as the key,
        store the result in a LinkedList refrence variable named elementList
            remove the list from the priorityMap
        */
        Integer highestPriority = getHighestPriority();
        LinkedList<E> elementList = priorityMap.get(highestPriority);
        if(elementList.isEmpty()){
            priorityMap.remove(highestPriority);
           
            return getHighestPriorityList();
        } else{
            return elementList;
        }
    }    
    private List<Integer> bubbleSort(List<Integer> numberList){
      /* 
        Sort the list of numberList using the bubble sort algorithm,
        Don't just copy the algorithm type it up, you will have to make adjustments for it to work with List
    */
      return numberList;
    }
}

