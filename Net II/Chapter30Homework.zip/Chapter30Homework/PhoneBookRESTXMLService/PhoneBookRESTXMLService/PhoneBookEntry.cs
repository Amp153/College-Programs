﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PhoneBookRESTXMLService
{
    class PhoneBookEntry
    {
        //was automatically implemented
        internal static PhoneBookEntry Format(string p1, string p2, string p3, string p4)
        {
            throw new NotImplementedException();
        }
    }
}
