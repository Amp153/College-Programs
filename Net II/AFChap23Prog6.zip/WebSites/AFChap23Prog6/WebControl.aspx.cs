﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WebControl : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        UnobtrusiveValidationMode = 
            System.Web.UI.UnobtrusiveValidationMode.None;

        if (IsPostBack) 
        {
            Validate();
            if (IsValid) 
            {
                //I can't get the text from the inputs no matter how hard I try.
                //string firstName = Request.Form.Get("txtFirst");
                //string lastName = txtLast.Text;
                //string email = txtEmail.value;
                //string phone = phone.value;

                
                outputLabel.Text = "Thank you for your submission <br />"+
                    "We recieved the following information";
                //outputLabel.Text += String.Format("Name: {0}{1}{2}E-mail: {3}{2}Phone: {4}{2}",firstName,lastName,"<br />",email,phone);
                outputLabel.Visible = true;
            }
        }
    }
}