﻿using System;
using Windows.UI;
using Windows.UI.Input;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Xaml.Shapes;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace Painter
{
   /// <summary>
   /// An empty page that can be used on its own or navigated to within a Frame.
   /// </summary>
   public sealed partial class MainPage : Page
   {
      private Sizes diameter = Sizes.MEDIUM; // set diameter of circle
      private Brush brushColor = new SolidColorBrush(Colors.Black); // set the drawing color
      private bool shouldPaint = false; // specify whether to paint

      private enum Sizes // size constants for diameter of the circle
      {
         SMALL = 5,
         MEDIUM = 15,
         LARGE = 30
      } // end enum Sizes

      public MainPage()
      {
         this.InitializeComponent();
      } // end constructor

      /// <summary>
      /// Invoked when this page is about to be displayed in a Frame.
      /// </summary>
      /// <param name="e">Event data that describes how this page was reached.  The Parameter
      /// property is typically used to configure the page.</param>
      protected override void OnNavigatedTo(NavigationEventArgs e)
      {
      } // end method OnNavigatedTo

      // paints a circle on the Canvas
      private void PaintCircle(Brush circleColor, PointerPoint point)
      {
         Ellipse newEllipse = new Ellipse(); // create an Ellipse   

         newEllipse.Fill = circleColor; // set Ellipse's color      
         newEllipse.Width = Convert.ToInt32(diameter); // set its horizontal diameter
         newEllipse.Height = Convert.ToInt32(diameter); // set its vertical diameter 

         // set the Ellipse's position            
         Canvas.SetTop(newEllipse, point.Position.Y);
         Canvas.SetLeft(newEllipse, point.Position.X);

         paintCanvas.Children.Add(newEllipse);
      } // end method PaintCircle

      private void redRadioButton_Checked(object sender, RoutedEventArgs e)
      {
         brushColor = new SolidColorBrush(Colors.Red);
      } // end method redRadioButton_Checked

      private void blueRadioButton_Checked(object sender, RoutedEventArgs e)
      {
         brushColor = new SolidColorBrush(Colors.Blue);
      } // end method blueRadioButton_Checked

      private void greenRadioButton_Checked(object sender, RoutedEventArgs e)
      {
         brushColor = new SolidColorBrush(Colors.Green);
      } // end method greenRadioButton_Checked

      private void blackRadioButton_Checked(object sender, RoutedEventArgs e)
      {
         brushColor = new SolidColorBrush(Colors.Black);
      } // end method blackRadioButton_Checked

      private void smallRadioButton_Checked(object sender, RoutedEventArgs e)
      {
         diameter = Sizes.SMALL;
      } // end method smallRadioButton_Checked

      private void mediumRadioButton_Checked(object sender, RoutedEventArgs e)
      {
         diameter = Sizes.MEDIUM;
      } // end method mediumRadioButton_Checked

      private void largeRadioButton_Checked(object sender, RoutedEventArgs e)
      {
         diameter = Sizes.LARGE;
      } // end method largeRadioButton_Checked

      private void undoButton_Click(object sender, RoutedEventArgs e)
      {
         int count = paintCanvas.Children.Count;   

         // if there are any shapes on Canvas remove the last one added
         if (count > 0)
            paintCanvas.Children.RemoveAt(count - 1);
      } // end method undoButton_Click

      private void clearButton_Click(object sender, RoutedEventArgs e)
      {
         paintCanvas.Children.Clear(); // clear the canvas
      } // end method clearButton_Click

      // handles paintCanvas's PointerPressed event
      private void paintCanvas_PointerPressed(object sender, PointerRoutedEventArgs e)
      {
         shouldPaint = true; // the user is drawing
      } // end method paintCanvas_PointerPressed

      // handles paintCanvas's MouseMove event
      private void paintCanvas_PointerMoved(object sender, PointerRoutedEventArgs e)
      {
         if (shouldPaint)
         {
            // draw a circle of selected color at current mouse position
            PointerPoint mousePosition = e.GetCurrentPoint(paintCanvas);
            PaintCircle(brushColor, mousePosition);
         } // end if
      } // end method paintCanvas_PointerMoved

      // handles paintCanvas's PointerReleased event
      private void paintCanvas_PointerReleased(object sender, PointerRoutedEventArgs e)
      {
         shouldPaint = false; // the user finished drawing
      } // end method paintCanvas_PointerReleased

      // handles paintCanvas's PointerCanceled event
      private void paintCanvas_PointerCanceled(object sender, PointerRoutedEventArgs e)
      {
         shouldPaint = false; // the user finished drawing
      } // end method paintCanvas_PointerCanceled

      // handles paintCanvas's PointerCaptureLost event
      private void paintCanvas_PointerCaptureLost(object sender, PointerRoutedEventArgs e)
      {
         shouldPaint = false; // the user finished drawing
      } // end method paintCanvas_PointerCaptureLost
   }
}
