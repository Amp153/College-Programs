﻿// Fig. 26.7: MainPage.xaml.cs
// Applying transforms to a Polygon.
using System;
using Windows.Foundation;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Shapes;

namespace DrawStars
{
   public sealed partial class MainPage : Page
   {
      Random random = new Random(); // for random color values
      Polygon star = new Polygon(); // used to define star

      // constructor
      public MainPage()
      {
         this.InitializeComponent();

         // determine horizonal center of screen 
         int centerX = 
            Convert.ToInt32(Window.Current.Bounds.Width / 2);

         // set initial star points
         star.Points.Add(new Point(centerX, 50));
         star.Points.Add(new Point(centerX + 12, 86));
         star.Points.Add(new Point(centerX + 44, 86));
         star.Points.Add(new Point(centerX + 18, 104));
         star.Points.Add(new Point(centerX + 28, 146));
         star.Points.Add(new Point(centerX, 122));
         star.Points.Add(new Point(centerX - 28, 146));
         star.Points.Add(new Point(centerX - 18, 104));
         star.Points.Add(new Point(centerX - 44, 86));
         star.Points.Add(new Point(centerX - 12, 86));

         RotateAndDrawStars(); // draw circle of stars
      } // end constructor

      // draw circle of stars in random colors
      private void RotateAndDrawStars()
      {
         mainCanvas.Children.Clear(); // remove previous stars

         // create 18 stars
         for (int count = 0; count < 18; ++count)
         {
            Polygon newStar = new Polygon(); // create a polygon object

            // copy star.Points collection into newStar.Points
            foreach (var point in star.Points)
               newStar.Points.Add(point);

            byte[] colorValues = new byte[3]; // create a Byte array
            random.NextBytes(colorValues); // create three random values
            
            // creates a random color brush
            newStar.Fill = new SolidColorBrush(Color.FromArgb(
               255, colorValues[0], colorValues[1], colorValues[2])); 

            // apply a rotation to the shape
            // used to rotate the star
            RotateTransform rotate = new RotateTransform();
            rotate.CenterX = Window.Current.Bounds.Width / 2;
            rotate.CenterY = Window.Current.Bounds.Height / 2;
            rotate.Angle = count * 20;
            newStar.RenderTransform = rotate;
            mainCanvas.Children.Add(newStar);
         } // end for
      } // end method RotateAndDrawStars

      // redraws stars in new colors each time user touches the canvas
      private void mainCanvas_PointerPressed(object sender,
         PointerRoutedEventArgs e)
      {
         RotateAndDrawStars();
      } // end method mainCanvas_PointerPressed
   } // end class MainPage
 } // end namespace DrawStars


/*************************************************************************
* (C) Copyright 1992-2014 by Deitel & Associates, Inc. and               *
* Pearson Education, Inc. All Rights Reserved.                           *
*                                                                        *
* DISCLAIMER: The authors and publisher of this book have used their     *
* best efforts in preparing the book. These efforts include the          *
* development, research, and testing of the theories and programs        *
* to determine their effectiveness. The authors and publisher make       *
* no warranty of any kind, expressed or implied, with regard to these    *
* programs or to the documentation contained in these books. The authors *
* and publisher shall not be liable in any event for incidental or       *
* consequential damages in connection with, or arising out of, the       *
* furnishing, performance, or use of these programs.                     *
*************************************************************************/