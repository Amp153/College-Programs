﻿// Fig. 26.5: MainPage.xaml.cs
// Customizing gradients.
using System;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace UsingGradients
{
   public sealed partial class MainPage : Page
   {
      // constructor
      public MainPage()
      {
         InitializeComponent();
      } // end constructor

      // change the starting color of the gradient when the user clicks
      private void startColorButton_Click(object sender, 
         RoutedEventArgs e)
      {
         // change the color to use the ARGB values specified by user
         firstStop.Color = Color.FromArgb(
            Convert.ToByte(fromAlpha.Text),
            Convert.ToByte(fromRed.Text),
            Convert.ToByte(fromGreen.Text),
            Convert.ToByte(fromBlue.Text));
      } // end method startColorButton_Click

      // change the ending color of the gradient when the user clicks
      private void endColorButton_Click(object sender, 
         RoutedEventArgs e)
      {
         // change the color to use the ARGB values specified by user
         secondStop.Color = Color.FromArgb(
            Convert.ToByte(toAlpha.Text),
            Convert.ToByte(toRed.Text),
            Convert.ToByte(toGreen.Text),
            Convert.ToByte(toBlue.Text));
      } // end method endColorButton_Click
    } // end class MainPage
 } // end namespace UsingGradients

/*************************************************************************
* (C) Copyright 1992-2014 by Deitel & Associates, Inc. and               *
* Pearson Education, Inc. All Rights Reserved.                           *
*                                                                        *
* DISCLAIMER: The authors and publisher of this book have used their     *
* best efforts in preparing the book. These efforts include the          *
* development, research, and testing of the theories and programs        *
* to determine their effectiveness. The authors and publisher make       *
* no warranty of any kind, expressed or implied, with regard to these    *
* programs or to the documentation contained in these books. The authors *
* and publisher shall not be liable in any event for incidental or       *
* consequential damages in connection with, or arising out of, the       *
* furnishing, performance, or use of these programs.                     *
*************************************************************************/