﻿// Fig. 25.x: MainPage.xaml.cs
// Using data binding
using System;
using System.Collections.Generic;
using Windows.UI.Xaml.Controls;

namespace CoverViewer
{
   public sealed partial class MainPage : Page
   {
      // list of Book objects
      private List<Book> books = new List<Book>();

      public MainPage()
      {
         this.InitializeComponent();

         // add Book objects to the List
         books.Add(new Book("C How to Program", "013299044X",
            "assets/images/small/chtp.jpg", 
            "assets/images/large/chtp.jpg"));
         books.Add(new Book("C++ How to Program", "0133378713",
            "assets/images/small/cpphtp.jpg", 
            "assets/images/large/cpphtp.jpg"));
         books.Add(new Book(
            "Internet and World Wide Web How to Program", "0132151006",
            "assets/images/small/iw3htp.jpg", 
            "assets/images/large/iw3htp.jpg"));
         books.Add(new Book("Java How to Program", "0132940949",
            "assets/images/small/jhtp.jpg",
            "assets/images/large/jhtp.jpg"));
         books.Add(new Book("Visual Basic How to Program", "0133406954",
            "assets/images/small/vbhtp.jpg", 
            "assets/images/large/vbhtp.jpg"));
         books.Add(new Book("Visual C# How to Program", "0133379337",
            "assets/images/small/vcshtp.jpg", 
            "assets/images/large/vcshtp.jpg"));

         booksListView.ItemsSource = books; // bind data to the list
         booksListView.SelectedIndex = 0; // select first item in ListView
      } // end constructor
   } // end class MainPage
} // end namespace CoverViewer

/**************************************************************************
 * (C) Copyright 1992-2014 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/