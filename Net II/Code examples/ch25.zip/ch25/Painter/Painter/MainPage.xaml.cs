﻿// Fig. 25.13: MainWindow.xaml.cs
// Code-behind for MainWindow.xaml.
using System;
using Windows.UI; // Colors class with predefined colors 
using Windows.UI.Input; // types related to event handling
using Windows.UI.Xaml; // types that support XAML
using Windows.UI.Xaml.Controls; // XAML GUI controls and supporting types
using Windows.UI.Xaml.Input; // types related to event handling
using Windows.UI.Xaml.Media; // graphics and multimedia capabilities
using Windows.UI.Xaml.Shapes; // Ellipse class and other shapes

namespace Painter
{
   public sealed partial class MainPage : Page
   {
      private Sizes diameter = Sizes.MEDIUM; // set diameter of circle
      private Brush brushColor = 
         new SolidColorBrush(Colors.Black); // set the drawing color
      private bool shouldPaint = false; // specify whether to paint

      private enum Sizes // size constants for diameter of the circle
      {
         SMALL = 5,
         MEDIUM = 15,
         LARGE = 30
      } // end enum Sizes

      public MainPage()
      {
         this.InitializeComponent();
      } // end constructor

      // paints a circle on the Canvas
      private void PaintCircle(Brush circleColor, PointerPoint point)
      {
         Ellipse newEllipse = new Ellipse(); // create an Ellipse   
         
         newEllipse.Fill = circleColor; // set Ellipse's color      
         newEllipse.Width = 
            Convert.ToInt32(diameter); // set its horizontal diameter
         newEllipse.Height = 
            Convert.ToInt32(diameter); // set its vertical diameter 

         // set the Ellipse's position            
         Canvas.SetTop(newEllipse, point.Position.Y);
         Canvas.SetLeft(newEllipse, point.Position.X);

         paintCanvas.Children.Add(newEllipse);
      } // end method PaintCircle

      // user chose red 
      private void redRadioButton_Checked(object sender, 
         RoutedEventArgs e)
      {
         brushColor = new SolidColorBrush(Colors.Red);
      } // end method redRadioButton_Checked

      // user chose blue
      private void blueRadioButton_Checked(object sender, 
         RoutedEventArgs e)
      {
         brushColor = new SolidColorBrush(Colors.Blue);
      } // end method blueRadioButton_Checked

      // user chose green
      private void greenRadioButton_Checked(object sender, 
         RoutedEventArgs e)
      {
         brushColor = new SolidColorBrush(Colors.Green);
      } // end method greenRadioButton_Checked

      // user chose black
      private void blackRadioButton_Checked(object sender,
         RoutedEventArgs e)
      {
         brushColor = new SolidColorBrush(Colors.Black);
      } // end method blackRadioButton_Checked

      // user chose small brush size
      private void smallRadioButton_Checked(object sender, 
         RoutedEventArgs e)
      {
         diameter = Sizes.SMALL;
      } // end method smallRadioButton_Checked

      // user chose medium brush size
      private void mediumRadioButton_Checked(object sender, 
         RoutedEventArgs e)
      {
         diameter = Sizes.MEDIUM;
      } // end method mediumRadioButton_Checked

      // user chose large brush size
      private void largeRadioButton_Checked(object sender, 
         RoutedEventArgs e)
      {
         diameter = Sizes.LARGE;
      } // end method largeRadioButton_Checked

      // remove last ellipse that was added to the paintCanvas
      private void undoButton_Click(object sender, RoutedEventArgs e)
      {
         int count = paintCanvas.Children.Count;

         // if there are any shapes on Canvas remove the last one added
         if (count > 0)
            paintCanvas.Children.RemoveAt(count - 1);
      } // end method undoButton_Click

      // delets the entire drawing
      private void deleteButton_Click(object sender, RoutedEventArgs e)
      {
         paintCanvas.Children.Clear(); // clear the canvas
      } // end method deleteButton_Click

      // handles paintCanvas's PointerPressed event
      private void paintCanvas_PointerPressed(object sender, 
         PointerRoutedEventArgs e)
      {
         shouldPaint = true; // the user is drawing
      } // end method paintCanvas_PointerPressed

      // handles paintCanvas's PointerMoved event
      private void paintCanvas_PointerMoved(object sender, 
         PointerRoutedEventArgs e)
      {
         if (shouldPaint)
         {
            // draw a circle of selected color at current pointer position
            PointerPoint pointerPosition = e.GetCurrentPoint(paintCanvas);
            PaintCircle(brushColor, pointerPosition);
         } // end if
      } // end method paintCanvas_PointerMoved

      // handles paintCanvas's PointerReleased event
      private void paintCanvas_PointerReleased(object sender, 
         PointerRoutedEventArgs e)
      {
         shouldPaint = false; // the user finished drawing
      } // end method paintCanvas_PointerReleased

      // handles paintCanvas's PointerCanceled event
      private void paintCanvas_PointerCanceled(object sender, 
         PointerRoutedEventArgs e)
      {
         shouldPaint = false; // the user finished drawing
      } // end method paintCanvas_PointerCanceled

      // handles paintCanvas's PointerCaptureLost event
      private void paintCanvas_PointerCaptureLost(object sender,
         PointerRoutedEventArgs e)
      {
         shouldPaint = false; // the user finished drawing
      } // end method paintCanvas_PointerCaptureLost

      // handles paintCanvas's PointerExited event
      private void paintCanvas_PointerExited(object sender, 
         PointerRoutedEventArgs e)
      {
         shouldPaint = false; // the user finished drawing
      } // end method paintCanvas_PointerExited
   } // end class MainPage
} // end namespace Painter


/**************************************************************************
 * (C) Copyright 1992-2014 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/