﻿// MainPage.xaml.cs
// Calculates bills using 15% and custom percentage tips
using System; // for classes String and Convert
using System.Windows; // for event handler argument classes
using System.Windows.Controls; // for event handler argument classes
using Microsoft.Phone.Controls; // for base class PhoneApplicationPage

namespace TipCalculator
{
   public partial class MainPage : PhoneApplicationPage
   {
      private decimal billAmount = 0.0M; // amount entered by the user
      private decimal customTipPercent = 0.18M; // custom tip percentage
       
      // Constructor
      public MainPage()
      {
         InitializeComponent();
      } // end constructor

      // executes when app has loaded
      private void PhoneApplicationPage_Loaded(object sender, 
         RoutedEventArgs e)
      {
         // update GUI based on billAmount and customTipPercent 
         update15PercentTip(); // update the 15% tip TextBlocks
         updateCustomTip(); // update the custom tip TextBlocks
         customTipPercentSlider.Value = 0.18; // initial value
         customTipPercentSlider.Maximum = 0.30; // maximum value
         amountTextBox.Focus(); // give amountTextBox the focus
      } // end method PhoneApplicationPage_Loaded
      
      // updates 15% tip TextBlocks
      private void update15PercentTip()
      {
         // calculate 15% tip and total
         decimal fifteenPercentTip = billAmount * 0.15M;
         decimal fifteenPercentTotal = billAmount + fifteenPercentTip;

         // display 15% tip and total formatted as currency
         tip15TextBlock.Text = String.Format("{0:C}", fifteenPercentTip);
         total15TextBlock.Text = 
            String.Format("{0:C}", fifteenPercentTotal); 
      } // end method update15PercentTip

      // updates the custom tip and total TextBlocks
      private void updateCustomTip()
      {
         // show customTipPercent in percentCustomTextBlock formatted as %
         percentCustomTextBlock.Text =
            String.Format("{0:P0}", customTipPercent); 

         // calculate the custom tip and total
         decimal customTip = billAmount * customTipPercent;
         decimal customTotal = billAmount + customTip;

         // display custom tip and total formatted as currency
         tipCustomTextBlock.Text = String.Format("{0:C}", customTip);
         totalCustomTextBlock.Text = String.Format("{0:C}", customTotal);
      } // end method updateCustomTip

      // updates 15% tip and total when user enters text in amountTextBox
      private void amountTextBox_TextChanged(object sender, 
         TextChangedEventArgs e)
      {
         // convert amountTextBox's text to a decimal
         try
         {
            billAmount = Convert.ToDecimal(amountTextBox.Text);
         } // end try
         catch (FormatException)
         {
            billAmount = 0.0M; // default if an exception occurs
         } // end catch 

         // display currency formatted bill amount
         update15PercentTip(); // update the 15% tip TextBlocks
         updateCustomTip(); // update the custom tip TextBlocks
      } // end method amountTextBox_TextChanged

      // updates custom tip and total when used changes slider value
      private void customTipPercentSlider_ValueChanged(object sender, 
         RoutedPropertyChangedEventArgs<double> e)
      {
         // sets customTipPercent to position of the Slider's thumb
         customTipPercent = Math.Round(
            Convert.ToDecimal(customTipPercentSlider.Value), 2);
         updateCustomTip(); // update the custom tip TextBlocks
      } // end method customTipPercentSlider_ValueChanged

      // force amountTextBox to keep the focus so keypad remains on screen
      private void amountTextBox_LostFocus(object sender, 
         RoutedEventArgs e)
      {
         amountTextBox.Focus();
      } // end method amountTextBox_LostFocus
   } // end class MainPage
} // end namespace TipCalculator


/*************************************************************************
* (C) Copyright 1992-2014 by Deitel & Associates, Inc. and               *
* Pearson Education, Inc. All Rights Reserved.                           *
*                                                                        *
* DISCLAIMER: The authors and publisher of this book have used their     *
* best efforts in preparing the book. These efforts include the          *
* development, research, and testing of the theories and programs        *
* to determine their effectiveness. The authors and publisher make       *
* no warranty of any kind, expressed or implied, with regard to these    *
* programs or to the documentation contained in these books. The authors *
* and publisher shall not be liable in any event for incidental or       *
* consequential damages in connection with, or arising out of, the       *
* furnishing, performance, or use of these programs.                     *
*************************************************************************/
