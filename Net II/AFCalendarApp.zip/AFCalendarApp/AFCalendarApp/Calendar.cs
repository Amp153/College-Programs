﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

//Anthony Fuller
//.Net II Final Project

namespace AFCalendarApp
{
    public partial class FormMain : Form
    {
        private string[][] arrayEvents = new string[][]{};
        private List<string> allEvents = new List<string>();
        private List<string> allDates = new List<string>();
        private StreamWriter filewriter; //writes data to text file
        private StreamReader filereader; //reads data from a text file
        private string fileName = "CalendarEvents";


        public FormMain()
        {
            InitializeComponent();
            lblDate.Text = monthCalendar1.TodayDate.ToShortDateString();
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            //making due without an associative array
            //arrayEvents[?][?] = allEvents[?] - easier to read
            //first time executes is when event is added
            //important, this is a bug - lblDate.Text won't update if anything is in allEvents array
                    for (int i = 0; i < allEvents.Count; i++)
                        arrayEvents[(int)allDates.IndexOf(lblDate.Text)]
                            [(int)allEvents.IndexOf(allEvents[i])] = allEvents[i];
                
            
            listEvents.Items.Clear();
            allEvents.Clear();
            lblDate.Text = monthCalendar1.SelectionRange.Start.ToShortDateString();

            //add events for that day
            for (int i = 0; i < arrayEvents[(int)allDates.IndexOf(lblDate.Text)].Count(); i++)
            {
                allEvents[i] = arrayEvents[(int)allDates.IndexOf(lblDate.Text)][i];
                listEvents.Items.Add(allEvents[i]);
            }


        }

        private void btnAddEvent_Click(object sender, EventArgs e)
        {
            //check for character I'm using to separate data when saving
            if(txtAddEvent.Text.Contains('^'))
                txtAddEvent.Text.Replace('^',' ');

            if (!allDates.Contains(lblDate.Text))
                allDates.Add(lblDate.Text);

            //important, this is a bug - check for whitespace
            txtAddEvent.Text.Trim();
            if (txtAddEvent.Text != " ")
                allEvents.Add(txtAddEvent.Text);

            listEvents.Items.Clear();

            //adds events to list
            for (int i = 0; i < allEvents.Count; i++)
                listEvents.Items.Add(allEvents[i]);

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (listEvents.SelectedItem != null)
            {
                //remove the event from the list
                allEvents.RemoveAt(listEvents.SelectedIndex);

                //corrects the list for the user
                listEvents.Items.Remove(listEvents.SelectedItem);
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            

            //save file
            try
            {
                //open file with write access
                FileStream output = new FileStream(fileName,
                    FileMode.OpenOrCreate, FileAccess.Write);

                //sets file to where data is written
                filewriter = new StreamWriter(output);
            }
            //exception if problem opening file
            catch (IOException)
            {
                MessageBox.Show("Error opening file", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

                try
                {
                    for (int i = 0; i < allDates.Count(); i++)
                    {
                        for (int j = 0; j < arrayEvents[(int)allDates.IndexOf(lblDate.Text)].Count(); j++)
                        {
                        allEvents[j] = arrayEvents[(int)allDates.IndexOf(lblDate.Text)][j];

                        filewriter.WriteLine(
                        allDates[i] + "^" + allEvents[j] + "^");
                        }
                
                    }
                }
                catch (IOException)
                {
                MessageBox.Show("Error saving file", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch(Exception)
                {
                    MessageBox.Show("An error has occured", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                if(filewriter != null)
                    try 
                    {
                        filewriter.Close();
                    }
                    catch (IOException)
                    {
                        MessageBox.Show("Error closing file", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
        }

        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try 
            {
                //open file with read access
                FileStream input = new FileStream(fileName,
                    FileMode.Open, FileAccess.Read);

                filereader = new StreamReader(input);
            }
            //exception if problem opening file
            catch (IOException)
            {
                MessageBox.Show("Error opening file", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            try 
            {
                string inputEverything = filereader.ReadLine();
                string[] inputArray = inputEverything.Split('^');

                //important, this is a bug - will try to add all events to allEvents array
                if (!allDates.Contains(inputArray[0]))
                    allDates.Add(inputArray[0]);
                allEvents.Add(inputArray[1]);

                filereader.Close();
            }
            //exception if problem reading file
            catch (IOException)
            {
                MessageBox.Show("Error reading file", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
