﻿using System;
using System.Drawing;
using System.Windows.Forms;

//Anthony Fuller
//.Net II
//Chapter 15 Program 17

namespace AFChapter15Program7
{
    public partial class TextBoxClass : Form
    {
        public TextBoxClass()
        {
            InitializeComponent();
        }



    }
}
