import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { GreetingPage } from './../greeting/greeting';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController) {

  }
  greet(nameInputElement:HTMLInputElement){
    let name = nameInputElement.value;
    this.navCtrl.push(GreetingPage,{name});
    //name:name
  }
}
