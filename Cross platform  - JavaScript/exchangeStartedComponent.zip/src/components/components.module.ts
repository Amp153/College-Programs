import { NgModule } from '@angular/core';
import { RateSelectorComponent } from './rate-selector/rate-selector';
@NgModule({
	declarations: [RateSelectorComponent],
	imports: [],
	exports: [RateSelectorComponent]
})
export class ComponentsModule {}
