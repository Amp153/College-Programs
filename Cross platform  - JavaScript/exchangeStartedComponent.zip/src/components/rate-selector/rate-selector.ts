import { Component, Output, EventEmitter } from '@angular/core';

/**
 * Generated class for the RateSelectorComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'rate-selector',
  templateUrl: 'rate-selector.html'
})
export class RateSelectorComponent {

  @Output() rateSelected = new EventEmitter<any>();

  constructor() {}

  convertCurrency(currency:HTMLSelectElement, conversion:HTMLSelectElement){
    let selectedCurrency:string = currency.value;
    let selectedConversion:string = conversion.value;
    this.rateSelected.emit([selectedCurrency, selectedConversion]);
  }
}
