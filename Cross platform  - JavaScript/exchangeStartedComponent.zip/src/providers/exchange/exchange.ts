import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
/*
  Generated class for the ExchangeProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class ExchangeProvider {
  private apiBase:string = "https://api.fixer.io";

  constructor(public https: HttpClient) {}

  public getExchangeRates(currency:string):Observable<ExchangeRate>{
    return this.https.get(this.apiBase + "/latest?base=" + currency)
    .map((response:ExchangeRateResponse)=>response.rates);
  }
}
interface ExchangeRateResponse{
  base:string;
  date:string;
  rates:ExchangeRate;
}
export class ExchangeRate{
  AUD:number;
  BGN:number;
  BRL:number;
  CAD:number;
  CHF:number;
  CNY:number;
  CZK:number;
  DKK:number;
  EUR:number;
  GBP:number;
  HKD:number;
  HRK:number;
  HUF:number;
  IDR:number;
  ILS:number;
  INR:number;
  ISK:number;
  JPY:number;
  KRW:number;
  MXN:number;
  MYR:number;
  NOK:number;
  NZD:number;
  PHP:number;
  PLN:number;
  RON:number;
  RUB:number;
  SEK:number;
  SGD:number;
  THB:number;
  TRY:number;
  USD:number;
  ZAR:number;
  constructor(){}
}
/*{"base":"USD","date":"2018-03-29","rates":
{"AUD":1.3015,"BGN":1.5874,"BRL":3.3226,"CAD":1.2901
,"CHF":0.95601,"CNY":6.2875,"CZK":20.636,"DKK":6.049
,"EUR":0.81162,"GBP":0.71009,"HKD":7.8481,"HRK":6.0322
,"HUF":253.33,"IDR":13744.0,"ILS":3.5112,"INR":65.17
,"ISK":98.612,"JPY":106.44,"KRW":1064.0,"MXN":18.282
,"MYR":3.868,"NOK":7.8541,"NZD":1.3877,"PHP":52.247
,"PLN":3.4174,"RON":3.7793,"RUB":57.536,"SEK":8.3467
,"SGD":1.3114,"THB":31.23,"TRY":3.975,"ZAR":11.867}} */