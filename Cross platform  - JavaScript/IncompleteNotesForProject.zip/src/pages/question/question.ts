import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { TriviaProvider, TriviaQuestion } from '../../providers/trivia/trivia';

/**
 * Generated class for the QuestionPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-question',
  templateUrl: 'question.html',
})
export class QuestionPage {
  category:string;
  difficulty:string;
  question:TriviaQuestion;
  constructor(public navCtrl: NavController, public navParams: NavParams, public triviaProvider:TriviaProvider) {
    this.category = navParams.get("selectedCategory");
    this.difficulty = navParams.get("selectedDifficulty");
    this.question = new TriviaQuestion();
    this.triviaProvider.getTriviaQuestion(this.category,this.difficulty).subscribe(question=>this.question = JSON.stringify(question));
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad QuestionPage');
  }

}
