import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import {QuestionPage} from '../question/question';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController) {}

  startGame(triviaCategory:HTMLSelectElement, triviaDiffculty:HTMLSelectElement){
    let selectedCategory:string = triviaCategory.value;
    let selectedDifficulty:string = triviaDiffculty.value;
    this.navCtrl.push(QuestionPage,{selectedCategory,selectedDifficulty});
    //console.log(selectedCategory,selectedDifficulty);
  }
}
