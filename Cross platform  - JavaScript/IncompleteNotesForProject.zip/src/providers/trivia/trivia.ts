import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { query } from '@angular/core/src/animation/dsl';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/Operator/map';

/*
  Generated class for the TriviaProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class TriviaProvider {
  private apiBase:string = "https://opentdb.com/api.php?";

  constructor(public http: HttpClient) {
    console.log('Hello TriviaProvider Provider');
  }
  public getTriviaQuestion(category:string,difficulty:string):Observable<TriviaQuestion>{
    let queryString = "?amount=1";
    if(category !="any"){
      queryString += `category=${category}`;
    }
    return this.http.get(this.apiBase+queryString+`&category=${category}&difficulty=${difficulty}`).map((response:TriviaQuestionResponse)=>response.results[0]);
  }

}
interface TriviaQuestionResponse{
response_code:number;
results:Array<string>;
}
enum TriviaQuestionType{
  multiple, boolean
}
export class TriviaQuestion{
  category:TriviaQuestionCategory;
  type:TriviaQuestionType;
  difficulty:TriviaQuestionDifficulty;
  question:string;
  correct_answer:string;
  incorrect_answer:string;
  constructor(){

  }
}
enum TriviaQuestionDifficulty{
  easy,hard
}
class TriviaQuestionCategory{
  static 15 = "something";
  static 16 = "something else";
}
//TriviaQuestionCategory[15];
