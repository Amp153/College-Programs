import { ApiProvider, Food } from './../../providers/api/api';
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-diet',
  templateUrl: 'diet.html',
})
export class DietPage {
  foods:Array<Food>;
  food:Food;
  currentFood:number = 0;
  constructor(public navCtrl: NavController, public navParams: NavParams,
  public apiProvider:ApiProvider) {
    let beastId = navParams.get("id");
    this.apiProvider.getDietForBeast(beastId).subscribe((foods)=>{
      this.foods = foods
    this.food = foods[0]});
  }
  nextFood(){
    this.currentFood++;
    if(this.currentFood > this.foods.length){
      this.currentFood = 0;
    }
    this.food = this.foods[this.currentFood];
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad DietPage');
  }

}
