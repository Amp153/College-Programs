import { NgModule } from '@angular/core';
import { BeastListComponent } from './beast-list/beast-list';
import { BeastSelectorComponent } from './beast-selector/beast-selector';
@NgModule({
	declarations: [BeastListComponent,
    BeastSelectorComponent],
	imports: [],
	exports: [BeastListComponent,
    BeastSelectorComponent]
})
export class ComponentsModule {}
