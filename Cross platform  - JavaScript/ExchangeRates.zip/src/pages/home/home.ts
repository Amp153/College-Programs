import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ExchangeProvider } from './../../providers/exchange/exchange';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  rates;
  constructor(public navCtrl: NavController, public exchange:ExchangeProvider) {
    this.exchange.getRates().subscribe(rates=>this.rates=JSON.stringify(rates));
  }

}
