import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
@Injectable()
export class ApiProvider {
  private apiBase = "http://api-lite.ga";
  constructor(public http: HttpClient) {}
  /* This will iterate over an object with
  arbitray keys and create an instance of the class Beast */
  public getByType(type:string):Observable<TypesResponse>{
    return this.http.get(this.apiBase + "/types/" + type)
      .map((response)=>{
        Object.keys(response).forEach((key)=>{
          let plainObj = response[key];
          response[key] = new Beast(plainObj.id,plainObj.location);
        });
        return response as TypesResponse;
      });
  }
  /* This will punt and say that the object has instances of Beast class
  as it's values */
  public getBySimpleType(type:string):Observable<TypesResponse>{
    return this.http.get(this.apiBase + "/types/" + type)
      .map((response: TypesResponse)=>response);
  }

  //get /diet/:beastid
  public getDietForBeast(beastId):Observable<Array<Food>>{
    return this.http.get(this.apiBase + "/diet/" + beastId) as Observable<Array<Food>>;
  }
}
export interface TypesResponse{
  [key:string]:Beast
}
export class Beast{
  constructor(public id:number,
              public location:string){
  }
}
export class Food{
  name:string;
  img:string;
}
