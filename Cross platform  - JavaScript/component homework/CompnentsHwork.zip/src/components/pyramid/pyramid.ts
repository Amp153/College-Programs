import { Component } from '@angular/core';

/**
 * Generated class for the PyramidComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'pyramid',
  templateUrl: 'pyramid.html'
})
export class PyramidComponent {

  text: string;
  pyramid:Pyramid;

  constructor() {
    console.log('Hello PyramidComponent Component');
    this.text = 'Pyramid loaded';
    this.pyramid = new Pyramid(2,4,6);
  }

}
class Pyramid{
  length:number;
  width:number;
  height:number;
  constructor(length:number,width:number,height:number){
    this.length = length;
    this.width = width;
    this.height = height;
  }
  get area(){
    return (this.length * this.width * this.height) / 2;
  }
}
