import { Component } from '@angular/core';

/**
 * Generated class for the DefComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'def',
  templateUrl: 'def.html'
})
export class DefComponent {

  text: string;
  def:Def;

  constructor() {
    console.log('Hello DefComponent Component');
    this.text = 'Def loaded';
    this.def = new Def('I\'m a string');
  }

}
class Def{
  base:string;
  constructor(base:string){
    this.base = base;
  }
  get letters(){
    return this.base + 'D'+'E'+'F';
  }
}
