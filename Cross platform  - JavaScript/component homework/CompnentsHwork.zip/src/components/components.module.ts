import { NgModule } from '@angular/core';
import { SquareComponent } from './square/square';
import { CommonModule } from '@angular/common';
import { TemperatureComponent } from './temperature/temperature';
import { CubeComponent } from './cube/cube';
import { BoxComponent } from './box/box';
import { PyramidComponent } from './pyramid/pyramid';
import { AbcComponent } from './abc/abc';
import { DefComponent } from './def/def';
import { HijComponent } from './hij/hij';
import { KlmComponent } from './klm/klm';
import { NopComponent } from './nop/nop';
import { QrsComponent } from './qrs/qrs';
import { TuvComponent } from './tuv/tuv';
import { WxyzComponent } from './wxyz/wxyz';
import { ParallelogramComponent } from './parallelogram/parallelogram';
import { TrapezoidComponent } from './trapezoid/trapezoid';

@NgModule({
	declarations: [SquareComponent,
    TemperatureComponent,
    CubeComponent,
    BoxComponent,
    PyramidComponent,
    AbcComponent,
    DefComponent,
    HijComponent,
    KlmComponent,
    NopComponent,
    QrsComponent,
    TuvComponent,
    WxyzComponent,
    ParallelogramComponent,
    TrapezoidComponent],
	imports: [CommonModule],
	exports: [SquareComponent,
    TemperatureComponent,
    CubeComponent,
    BoxComponent,
    PyramidComponent,
    AbcComponent,
    DefComponent,
    HijComponent,
    KlmComponent,
    NopComponent,
    QrsComponent,
    TuvComponent,
    WxyzComponent,
    ParallelogramComponent,
    TrapezoidComponent]
})
export class ComponentsModule {}
