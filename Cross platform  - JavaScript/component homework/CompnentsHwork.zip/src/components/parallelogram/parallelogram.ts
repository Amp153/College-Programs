import { Component } from '@angular/core';

/**
 * Generated class for the ParallelogramComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'parallelogram',
  templateUrl: 'parallelogram.html'
})
export class ParallelogramComponent {

  text: string;
  parallelogram:Parallelogram;

  constructor() {
    console.log('Hello ParallelogramComponent Component');
    this.text = 'Parallelogram loaded';
    this.parallelogram = new Parallelogram(4,5);
  }

}
class Parallelogram{
  base:number;
  height:number;
  constructor(base:number,height:number){
    this.base = base;
    this.height = height;
  }
  get area(){
    return this.base * this.height;
  }
}