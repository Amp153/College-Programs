import { Component } from '@angular/core';

/**
 * Generated class for the BoxComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'box',
  templateUrl: 'box.html'
})
export class BoxComponent {

  text: string;
  box:Box;

  constructor() {
    console.log('Hello BoxComponent Component');
    this.text = 'Box loaded';
    this.box = new Box(2,4,6);
  }

}

class Box{
  length:number;
  width:number;
  height:number;
  constructor(length:number,width:number,height:number){
    this.length = length;
    this.width = width;
    this.height = height;
  }
  get area(){
    return this.length * this.width * this.height;
  }
}
