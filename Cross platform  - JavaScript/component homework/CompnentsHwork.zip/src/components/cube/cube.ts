import { Component } from '@angular/core';

/**
 * Generated class for the CubeComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'cube',
  templateUrl: 'cube.html'
})
export class CubeComponent {

  text: string;
  cube:Cube;

  constructor() {
    console.log('Hello CubeComponent Component');
    this.text = 'Cube loaded';
    this.cube = new Cube(5);
  }

}
class Cube{
  base:number;
  constructor(base:number){
    this.base = base;
  }
  get area(){
    return this.base * this.base * this.base;
  }
}
