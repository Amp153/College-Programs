import { Component } from '@angular/core';

/**
 * Generated class for the NopComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'nop',
  templateUrl: 'nop.html'
})
export class NopComponent {

  text: string;
  nop:Nop;

  constructor() {
    console.log('Hello NopComponent Component');
    this.text = 'Nop loaded';
    this.nop = new Nop('A string');
  }

}
class Nop{
  base:string;
  constructor(base:string){
    this.base = base;
  }
  get letters(){
    return this.base + 'N'+'O'+'P';
  }
}
