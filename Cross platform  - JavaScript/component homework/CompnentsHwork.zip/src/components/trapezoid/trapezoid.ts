import { Component } from '@angular/core';

/**
 * Generated class for the TrapezoidComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'trapezoid',
  templateUrl: 'trapezoid.html'
})
export class TrapezoidComponent {

  text: string;
  trapezoid:Trapezoid;

  constructor() {
    console.log('Hello TrapezoidComponent Component');
    this.text = 'Trapezoid loaded';
    this.trapezoid = new Trapezoid(2,4,5);
  }

}
class Trapezoid{
  baseOne:number;
  baseTwo:number;
  height:number;
  constructor(baseOne:number,baseTwo:number,height:number){
    this.baseOne = baseOne;
    this.baseTwo = baseTwo;
    this.height = height;
  }
  get area(){
    return ((this.baseOne * this.baseTwo) / 2) * this.height;
  }
}