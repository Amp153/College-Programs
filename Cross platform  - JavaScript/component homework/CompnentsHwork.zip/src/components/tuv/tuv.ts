import { Component } from '@angular/core';

/**
 * Generated class for the TuvComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'tuv',
  templateUrl: 'tuv.html'
})
export class TuvComponent {

  text: string;
  tuv:Tuv;

  constructor() {
    console.log('Hello TuvComponent Component');
    this.text = 'Tuv loaded';
    this.tuv = new Tuv('More words?');
  }

}
class Tuv{
  base:string;
  constructor(base:string){
    this.base = base;
  }
  get letters(){
    return this.base + 'T'+'U'+'V';
  }
}