import { Component } from '@angular/core';

/**
 * Generated class for the AbcComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'abc',
  templateUrl: 'abc.html'
})
export class AbcComponent {

  text: string;
  abc:Abc;

  constructor() {
    console.log('Hello AbcComponent Component');
    this.text = 'Abc loaded';
    this.abc = new Abc('This is a string ');
  }

}
class Abc{
  base:string;
  constructor(base:string){
    this.base = base;
  }
  get letters(){
    return this.base + 'A'+'B'+'C';
  }
}
