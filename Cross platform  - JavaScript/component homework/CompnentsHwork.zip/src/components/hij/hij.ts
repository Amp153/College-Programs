import { Component } from '@angular/core';

/**
 * Generated class for the HijComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'hij',
  templateUrl: 'hij.html'
})
export class HijComponent {

  text: string;
  hij:Hij;

  constructor() {
    console.log('Hello HijComponent Component');
    this.text = 'Hij loaded';
    this.hij = new Hij('Another string ');
  }

}
class Hij{
  base:string;
  constructor(base:string){
    this.base = base;
  }
  get letters(){
    return this.base + 'H'+'I'+'J';
  }
}
