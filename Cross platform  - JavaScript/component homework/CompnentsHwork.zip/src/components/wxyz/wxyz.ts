import { Component } from '@angular/core';

/**
 * Generated class for the WxyzComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'wxyz',
  templateUrl: 'wxyz.html'
})
export class WxyzComponent {

  text: string;
  wxyz:Wxyz;

  constructor() {
    console.log('Hello WxyzComponent Component');
    this.text = 'Wxyz loaded';
    this.wxyz = new Wxyz('This is the final one');
  }

}
class Wxyz{
  base:string;
  constructor(base:string){
    this.base = base;
  }
  get letters(){
    return this.base + 'W'+'X'+'Y'+'Z';
  }
}