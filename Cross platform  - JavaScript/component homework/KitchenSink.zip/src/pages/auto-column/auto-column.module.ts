import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AutoColumnPage } from './auto-column';

@NgModule({
  declarations: [
    AutoColumnPage,
  ],
  imports: [
    IonicPageModule.forChild(AutoColumnPage),
  ],
})
export class AutoColumnPageModule {}
