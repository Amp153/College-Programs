import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { AutoColumnPage } from '../auto-column/auto-column';
import { SpecifyColumnPage } from '../specify-column/specify-column';
import { OffsetColumnPage } from '../offset-column/offset-column';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController) {

  }

  goTo(pageName){
    switch(pageName){
      case "autoColumn":
        this.navCtrl.push(AutoColumnPage);
        break;
      case "specifyColumn":
        this.navCtrl.push(SpecifyColumnPage);
        break;
      case "offsetColumn":
        this.navCtrl.push(OffsetColumnPage);
        break;
    }

  }

}
