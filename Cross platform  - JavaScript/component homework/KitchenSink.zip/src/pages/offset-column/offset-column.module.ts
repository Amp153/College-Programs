import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OffsetColumnPage } from './offset-column';

@NgModule({
  declarations: [
    OffsetColumnPage,
  ],
  imports: [
    IonicPageModule.forChild(OffsetColumnPage),
  ],
})
export class OffsetColumnPageModule {}
