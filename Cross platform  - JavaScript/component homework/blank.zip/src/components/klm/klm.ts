import { Component } from '@angular/core';

/**
 * Generated class for the KlmComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'klm',
  templateUrl: 'klm.html'
})
export class KlmComponent {

  text: string;
  klm:Klm;

  constructor() {
    console.log('Hello KlmComponent Component');
    this.text = 'Hello World';
    this.klm = new Klm('The hidden G ');
  }

}
class Klm{
  base:string;
  constructor(base:string){
    this.base = base;
  }
  get letters(){
    return this.base + 'K'+'L'+'M';
  }
}
