import { Component } from '@angular/core';

/**
 * Generated class for the QrsComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'qrs',
  templateUrl: 'qrs.html'
})
export class QrsComponent {

  text: string;
  qrs:Qrs;

  constructor() {
    console.log('Hello QrsComponent Component');
    this.text = 'Hello World';
    this.qrs = new Qrs('more words');
  }

}
class Qrs{
  base:string;
  constructor(base:string){
    this.base = base;
  }
  get letters(){
    return this.base + 'Q'+'R'+'S';
  }
}
