import { Component } from '@angular/core';

/**
 * Generated class for the SquareComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'square',
  templateUrl: 'square.html'
})
export class SquareComponent {

  text: string;
  square:Square;

  constructor() {
    console.log('Hello SquareComponent Component');
    this.text = 'Hello World';
    this.square = new Square(5);
  }

}
class Square{
  base:number;
  constructor(base:number){
    this.base = base;
  }
  get area(){
    return this.base * this.base;
  }
}
