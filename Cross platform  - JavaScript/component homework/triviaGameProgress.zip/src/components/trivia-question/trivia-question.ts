import { Component, Input } from '@angular/core';
import { TriviaQuestion } from '../../providers/trivia-question/trivia-question';

/**
 * Generated class for the TriviaQuestionComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'trivia-question',
  templateUrl: 'trivia-question.html'
})
export class TriviaQuestionComponent {

  @Input()question:TriviaQuestion;
  /*constructor(){
    this.question = new TriviaQuestion();
  }*/

}
