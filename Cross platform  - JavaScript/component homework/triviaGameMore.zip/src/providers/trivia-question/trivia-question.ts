import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Rx';


@Injectable()
export class TriviaQuestionProvider {

  constructor(public http: HttpClient) {

    }
    loadTriviaQuestion():Observable<TriviaQuestion>{

      return this.http
        .get("https://opentdb.com/api.php?amount=1&type=boolean")
        .map((response:any)=>
          /*console.log(response);*/
          new TriviaQuestion(response.results[0]));
    }
}
export class TriviaQuestion{
  category:string;
  type:string;
  difficulty:string;
  question:string;
  correct_answer:string;
  incorrect_answer:Array<String>;
  constructor(map = {
    category: "",
    type : "",
    difficulty : "",
    question : "",
    correct_answer : "",
    incorrect_answer :[]
  }){

    this.category = map.category;
    this.type = map.type;
    this.difficulty = map.difficulty;
    this.question = map.question;
    this.correct_answer = map.correct_answer;
    this.incorrect_answer = map.incorrect_answer;
  }
}
