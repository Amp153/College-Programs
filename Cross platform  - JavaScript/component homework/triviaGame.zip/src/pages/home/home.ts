import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { TriviaQuestionProvider, TriviaQuestion} from '../../providers/trivia-question/trivia-question';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  triviaQuestion:TriviaQuestion;
  constructor(public navCtrl: NavController, public triviaQuestionProvider:TriviaQuestionProvider) {
    this.triviaQuestion = new TriviaQuestion();
    triviaQuestionProvider.loadTriviaQuestion().subscribe((triviaQuestion:TriviaQuestion)=>{
      this.triviaQuestion = triviaQuestion;
    });

    console.log("This will run before the callback");
  }

}
