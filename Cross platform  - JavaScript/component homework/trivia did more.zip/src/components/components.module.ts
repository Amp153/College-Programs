import { NgModule } from '@angular/core';
import { TriviaQuestionComponent } from './trivia-question/trivia-question';
import { CommonModule } from '@angular/common';
@NgModule({
	declarations: [TriviaQuestionComponent],
	imports: [CommonModule],
	exports: [TriviaQuestionComponent]
})
export class ComponentsModule {}
