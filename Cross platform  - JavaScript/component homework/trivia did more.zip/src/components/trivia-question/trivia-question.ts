import { Component, Input } from '@angular/core';
import { TriviaQuestion } from '../../providers/trivia-question/trivia-question';

/**
 * Generated class for the TriviaQuestionComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'trivia-question',
  templateUrl: 'trivia-question.html'
})
export class TriviaQuestionComponent {

  @Input()question:TriviaQuestion;
  /*constructor(){
    this.question = new TriviaQuestion();
  }*/

  correct: number;
  incorrect: number;

  questionTrue(event){
    if (this.question.correct_answer === 'True'){
      if(!(this.correct >= 0))
        this.correct = 0;
        this.correct += 1;
    }
    if (this.question.correct_answer === 'False'){
    if(!(this.incorrect >= 0))
        this.incorrect = 0;
        this.incorrect += 1;
    }
    console.log('Correct:' + this.correct);
    console.log('Incorrect:' + this.incorrect);
    console.log('Total:' + (this.correct + this.incorrect));
  }

  questionFalse(event){
    if (this.question.correct_answer === 'False'){
      if(!(this.correct >= 0))
        this.correct = 0;
        this.correct += 1;
    }
    if (this.question.correct_answer === 'True'){
      if(!(this.incorrect >= 0))
          this.incorrect = 0;
          this.incorrect += 1;
      }
      console.log('Correct:' + this.correct);
      console.log('Incorrect:' + this.incorrect);
      console.log('Total:' + (this.correct + this.incorrect));
  }

  //For testing
  logEvent(event){
    console.log(event);
  }

}
