import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { RatesPage } from '../rates/rates';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController) {}

  getRates(currencySelected:string, conversionSelected:string){
    console.log(currencySelected);
    this.navCtrl.push(RatesPage,{currencySelected, conversionSelected});
  }
}
