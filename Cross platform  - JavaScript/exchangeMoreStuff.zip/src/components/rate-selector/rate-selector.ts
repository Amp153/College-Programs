import { Component, Output, EventEmitter } from '@angular/core';

/**
 * Generated class for the RateSelectorComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'rate-selector',
  templateUrl: 'rate-selector.html'
})
export class RateSelectorComponent {

  @Output() currencySelected = new EventEmitter<String>();
  @Output() conversionSelected = new EventEmitter<String>();

  convertCurrency(currency:HTMLSelectElement, conversion:HTMLSelectElement){
    let selectedCurrency:string = currency.value;
    let selectedConversion:string = conversion.value;
    console.log('component selectedCurrency '+selectedCurrency);
    console.log('component selectedConversion '+selectedConversion);
    this.currencySelected.emit(selectedCurrency);
    this.conversionSelected.emit(selectedConversion);
  }
}
