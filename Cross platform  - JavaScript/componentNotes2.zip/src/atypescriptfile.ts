import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'parent',
  template: `<h1>This is parent.</h1>{{teddyBear}}
  <input #newToy/><button (click)="teddyBear = newToy.value">Give toy</button>
  <child [toy]="teddyBear" (crying)="shutoffBabyMonitor()"></child>`
})
export class Parent{
  teddyBear:string = "Teddy Bear";
  shutoffBabyMonitor(){
    console.log("Parent has checked out");
    setTimeout(()=>this.teddyBear="dog",1000);
  }
}

@Component({
  selector: 'child',
  template: `<h1 (click)="h1Clicked()">This is child</h1>{{toy}}<grand-child [heirloom]="toy"></grand-child>`
})
export class Child{
  @Input()toy:string;
  @Output()crying = new EventEmitter;
  constructor(){
    setTimeout(()=>{
      console.log("child has started crying");
      this.crying.emit();
    },5000);
  }
  h1Clicked(){
    this.crying.emit();
  }
}

@Component({
  selector:'grand-child',
  template:`<h1>grandchild</h1>{{heirloom}}`
})
export class GrandChild{
  @Input()heirloom:string;
}
