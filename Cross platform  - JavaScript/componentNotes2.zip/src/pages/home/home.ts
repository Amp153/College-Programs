import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Geometry } from '../../component';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  geometries:Array<Geometry> = [];
  addGeometry(geometry:Geometry){
    this.geometries.push(geometry);
  }
}
