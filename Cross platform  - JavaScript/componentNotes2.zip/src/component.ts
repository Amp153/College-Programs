import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector:"geometry-input",
  template:`
  <p>Length:<input #length /></p>
  <p>Width:<input #width /></p>
  <button (click)="makeGeometry(length,width)">Make Geometry</button>`
})
export class GeometryInputComponent{
  @Output() geomCreated:EventEmitter<Geometry> = new EventEmitter<Geometry>();

  makeGeometry(lengthInput:HTMLInputElement, widthInput:HTMLInputElement){
    let length:number = parseInt(lengthInput.value);
    let width:number = parseInt(widthInput.value);
    let geom = new Geometry(length, width);
    this.geomCreated.emit(geom);
  }
}

@Component({
  selector: "geometry-list",
  template:`
  <ul>
    <li *ngFor="let geometry of geometries">
      <geometry [geometry]="geometry"></geometry>
    </li>
  </ul>`
})
export class GeometryListComponent{
  @Input() geometries:Array<Geometry>;
}

@Component({
  selector:"geometry",
  template: `Length:{{geometry.length}} Width:{{geometry.width}} Area:{{geometry.area}}`
})
export class GeometryComponent{
  @Input() geometry:Geometry;
}

export class Geometry{
  constructor(public length:number, public width:number){}
  get area():number{
    return this.length * this.width;
  }
}
