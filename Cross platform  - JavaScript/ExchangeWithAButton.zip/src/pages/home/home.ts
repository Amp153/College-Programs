import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ExchangeProvider } from './../../providers/exchange/exchange';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  rates;
  export public base:string;

  constructor(public navCtrl: NavController, public exchange:ExchangeProvider) {
    //this.exchange.getRates().subscribe(rates=>this.rates=JSON.stringify(rates));
  }

  createQuery(baseInput:HTMLInputElement, dateInput:HTMLInputElement){


    this.base = baseInput.value;

    this.exchange.getRates().subscribe(rates=>this.rates=JSON.stringify(rates));

  }
}
