import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { base } from '../../pages/home/home';

/*
  Generated class for the ExchangeProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class ExchangeProvider {

  apibase = "https://api.fixer.io";
  base = this.base;

  constructor(public http: HttpClient) {
    console.log('Hello ExchangeProvider Provider');
  }
  getRates(){
    return this.http.get(this.apibase + "/latest?base=" + base);
  }
}
