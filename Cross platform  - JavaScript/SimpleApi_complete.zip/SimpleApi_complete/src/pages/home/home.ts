import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ApiProvider, TypesResponse, Beast } from '../../providers/api/api';
import { DietPage } from '../diet/diet';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  beasts:TypesResponse = {};
  constructor(public navCtrl: NavController,
              public apiProvider:ApiProvider) {}
  loadBeasts(type:string){
    this.apiProvider.getByType(type).subscribe(obj=>this.beasts=obj);
  }
  showDiet(beast:Beast){
    this.navCtrl.push(DietPage,{id:beast.id});
  }
}
