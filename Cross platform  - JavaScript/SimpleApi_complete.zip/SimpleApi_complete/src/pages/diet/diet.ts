import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ApiProvider, Food } from '../../providers/api/api';
import { AboutFoodPage} from '../about-food/about-food';
@IonicPage()
@Component({
  selector: 'page-diet',
  templateUrl: 'diet.html',
})
export class DietPage {
  foods:Array<Food> = [];
  food:Food = {img:"",name:""};
  currentFood:number = 0;
  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              public apiProvider:ApiProvider) {
    let beastId = navParams.get("id");
    this.apiProvider.getDietForBeast(beastId).subscribe((foods)=>{
      this.foods = foods
      this.food = foods[0];
    });
  }
  nextFood(){
    this.currentFood++;
    if(this.currentFood > this.foods.length-1){
      this.currentFood = 0;
    }
    this.food = this.foods[this.currentFood];
  }
  previousFood(){
    this.currentFood--;
    if(this.currentFood < 0){
      this.currentFood = this.foods.length - 1;
    }
    this.food = this.foods[this.currentFood];
  }
  about(foodName:string){
    this.navCtrl.push(AboutFoodPage,{foodName});
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad DietPage');
  }

}
