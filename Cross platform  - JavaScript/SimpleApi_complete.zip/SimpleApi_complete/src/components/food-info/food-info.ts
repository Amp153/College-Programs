import { Component,Input } from '@angular/core';
import { FoodInfo } from '../../providers/api/api';

@Component({
  selector: 'food-info',
  templateUrl: 'food-info.html'
})
export class FoodInfoComponent {
  @Input() foodName:string;
  @Input() foodInfo:FoodInfo;
  constructor() {}

}
