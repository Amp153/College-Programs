import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Student } from './providers';

@Component({
  selector:'student',
  template:`
  <h5>{{student.firstName}} {{student.lastName}}</h5>
  <p>{{student.grade}}% for a {{student.letterGrade}}</p>
  `
})
export class StudentComponent{
  @Input() student:Student;
}

@Component({
  selector:'student-list',
  template:`
  <ul>
    <li *ngFor="let student of students" (click)="studentClicked(student)">
      <student [student]="student"></student>
    </li>
  </ul>
  `
})
export class StudentListComponent{
  @Input() students:Array<Student>;
  @Output() selected:EventEmitter<Student> = new EventEmitter<Student>();
  studentClicked(student:Student){
    this.selected.emit(student);
  }
}
