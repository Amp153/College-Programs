import { Injectable } from "@angular/core";

@Injectable()
export class StudentProvider{
  classRoster:Array<Student>
  constructor(){
    this.classRoster = [];
    let bob:Student = new Student();
    bob.firstName = "Bob";
    bob.lastName = "Smith";
    bob.grade = 0;
    this.classRoster.push(bob);
  }

  withdraw(firstName:string){
    this.classRoster = this.classRoster.filter((student:Student)=>student.firstName != firstName);
  }
}

export class Student{
  firstName:string;
  lastName:string;
  grade:number;

  get letterGrade():string{
    if(this.grade < 59.9){
      return "F";
    }else{
      return "A";
    }
  }
}
