import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { StudentProvider, Student } from '../../providers';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  students:Array<Student>
  constructor(private studentProvider:StudentProvider) {
    this.students = this.studentProvider.classRoster;
  }
  withdraw(student:Student){
    this.studentProvider.withdraw(student.firstName);
    this.students = this.studentProvider.classRoster;
  }

}
