import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
@Injectable()
export class TriviaProvider {
  private apiBase:string = "https://opentdb.com/api.php";

  constructor(public http: HttpClient) {}

  public getTriviaQuestion(category:string,difficulty:string):Observable<TriviaQuestion>{
    let queryString = "?amount=1";
    if(category != "any"){
      queryString += `&category=${category}`;
    }
    if(difficulty != "any"){
      queryString += `&difficulty=${difficulty}`;
    }
    return this.http.get(this.apiBase + queryString)
    .map((response:TriviaQuestionResponse)=>response.results[0]);
  }

}
interface TriviaQuestionResponse{
  response_code:number;
  results:Array<TriviaQuestion>;
}
export class TriviaQuestion{
  category:TriviaQuestionCategory;
  type:TriviaQuestionType;
  difficulty:TriviaQuestionDifficulty;
  question:string;
  correct_answer:string;
  incorrect_answers:Array<string>;
  constructor(){

  }
}
enum TriviaQuestionType{
  multiple, boolean
}
enum TriviaQuestionDifficulty{
  easy,medium,hard
}
class TriviaQuestionCategory{
  static 15 = "Entertainment: Video Games";
  static 16 = "Entertainment: Board Games";
  static 18 = "Science: Computers";
  static 19 = "Science: Mathematics"
}

