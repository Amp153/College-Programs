import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { RatesPage } from '../rates/rates';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController) {}

  convertCurrency(currency:HTMLSelectElement){
    let selectedCurrency:string = currency.value;
    this.navCtrl.push(RatesPage,{selectedCurrency});
  }
}
