import { Component, Output, EventEmitter } from '@angular/core';
@Component({
  selector: 'beast-selector',
  templateUrl: 'beast-selector.html'
})
export class BeastSelectorComponent {
  @Output() beastSelected = new EventEmitter<String>();
  constructor() {}

  loadBeasts(typeSelect:HTMLSelectElement){
    let type:string = typeSelect.value;
    this.beastSelected.emit(type);
  }

}
