import { NgModule } from '@angular/core';
import { BeastListComponent } from './beast-list/beast-list';
import { BeastSelectorComponent } from './beast-selector/beast-selector';
import { FoodInfoComponent } from './food-info/food-info';
@NgModule({
	declarations: [BeastListComponent,
    BeastSelectorComponent,
    FoodInfoComponent],
	imports: [],
	exports: [BeastListComponent,
    BeastSelectorComponent,
    FoodInfoComponent]
})
export class ComponentsModule {}
