import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/forkJoin';
@Injectable()
export class ApiProvider {
  private apiBase = "http://api-lite.ga";
  constructor(public http: HttpClient) {}
  /* This will iterate over an object with
  arbitray keys and create an instance of the class Beast */
  public getByType(type:string):Observable<TypesResponse>{
    return this.http.get(this.apiBase + "/types/" + type)
      .map((response)=>{
        Object.keys(response).forEach((key)=>{
          let plainObj = response[key];
          response[key] = new Beast(plainObj.id,plainObj.location);
        });
        return response as TypesResponse;
      });
  }
  /* This will punt and say that the object has instances of Beast class
  as it's values */
  public getBySimpleType(type:string):Observable<TypesResponse>{
    return this.http.get(this.apiBase + "/types/" + type)
      .map((response: TypesResponse)=>response);
  }

  //get /diet/:beastid
  public getDietForBeast(beastId):Observable<Array<Food>>{
    return this.http.get(this.apiBase + "/diet/" + beastId) as Observable<Array<Food>>;
  }

  public getFoodInfo(foodName:string):Observable<[FoodResponse,FoodImageResponse]>{
    let foodObservable = this.http.get(this.apiBase + "/food/" + foodName) as Observable<FoodResponse>;
    let foodImageObservable = this.http.get(this.apiBase + "/foodimage/" + foodName) as Observable<FoodImageResponse>;

    return Observable.forkJoin(foodObservable,foodImageObservable).map((responses)=> new FoodInfo(responses[0].about,responses[1].img));
  }
}
export class FoodInfo{
  constructor(public about:string,public img:string){

  }
}
interface FoodResponse{
  about:string;
}
interface FoodImageResponse{
  img:string;
}
export interface TypesResponse{
  [key:string]:Beast
}
export class Beast{
  constructor(public id:number,
              public location:string){
  }
}
export class Food{
  name:string;
  img:string;
}
