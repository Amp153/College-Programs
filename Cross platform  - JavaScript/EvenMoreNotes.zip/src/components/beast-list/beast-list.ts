import { Component, Input,Output,EventEmitter } from '@angular/core';
import { TypeResponse, Beast } from '../../providers/api/api';


@Component({
  selector: 'beast-list',
  templateUrl: 'beast-list.html'
})
export class BeastListComponent {
  @Input() beasts:TypeResponse;
  @Output() entryClicked = new EventEmitter<Beast>();
  constructor() {}

  objectKeys(obj:any){
    return Object.keys(obj);
  }
  beastClicked(beast:Beast){
    this.entryClicked.emit(beast);
  }
}
