import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  users:Array<User>;
  constructor(public navCtrl: NavController, private storage:Storage) {
    //this.users = [new User(), new User()]; for testing with users in the database
    this.users = [];

    //For keeping the data in the database upon page refresh, database is tied to the localhost:8100
    //tried to make it look neater
    this.storage.ready()
    .then(()=>this.storage.get("users"))
    .then((usersString)=>this.users = JSON.parse(usersString) || [])
    .then((users)=>this.users = users.map((plainUser)=>new User(plainUser)));
    /*
    this.storage.ready().then(()=>{
      this.storage.get("users").then(usersString=>{
        this.users = JSON.parse(usersString) || [];
      });
    });*/
  }

  //Made after everything else confirmed to work
  //adds user input to database
  addUser(nameInput:HTMLInputElement, ageInput:HTMLInputElement){
  const user = new User();
  user.name = nameInput.value;
  user.age = parseInt(ageInput.value);
  this.users.push(user);
  //Had to add this code otherwise storing still wont be persistent
  this.storage.ready()
  .then(()=>this.storage.set("users",JSON.stringify(this.users)));
  }
}

class User{
  //id?:number;
  name:string;
  age:number;
  constructor(map={
    name : "",
    age : 0,
    //id : -1
  }){
    //this.id = map.id;
    this.age = map.age;
    this.name = map.name;
  }
}
