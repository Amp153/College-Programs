import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ApiListProvider, Entry } from '../../providers/api-list/api-list';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  entries:Array<Entry>;
  constructor(public navCtrl: NavController, private apiList:ApiListProvider) {
    apiList.entries().subscribe(entries=>this.entries=entries);
  }

}
