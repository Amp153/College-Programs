import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';

/*
  Generated class for the ApiListProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class ApiListProvider {
  apiBase:string;
  constructor(public http: HttpClient) {
    this.apiBase = "https://api.publicapis.org";
  }
  public entries():Observable<Entry[]>{
    return this.http.get(this.apiBase +
      "/entries").map((entriesResponse:EntriesResponseObject)=>entriesResponse.entries);
  }

}
/*
Parameter 	Type 	Data Type 	Description 	Required
title 	query 	string 	name of entry (matches via substring - i.e. "at" would return "cat" and "atlas") 	No
description 	query 	string 	description of entry (matches via substring) 	No
auth 	query 	string 	auth type of entry (can only be values matching in project or null) 	No
https 	query 	bool 	return entries that support HTTPS or not 	No
cors 	query 	string 	CORS support for entry ("yes", "no", or "unknown") 	No
category 	query 	string 	return entries of a specific category 	No
*/
interface EntriesResponseObject{
  count:number;
  entries:Array<Entry>;
}
export class Entry{
  API:string;
  Description:string;
  Auth:string;
  HTTPS:boolean;
  Cors:string;
  Link:string;
  Category:string;
}
