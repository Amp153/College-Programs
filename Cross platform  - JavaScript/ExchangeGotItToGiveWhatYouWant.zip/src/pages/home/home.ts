import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { RatesPage } from '../rates/rates';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController) {}

  convertCurrency(currency:HTMLSelectElement, conversion:HTMLSelectElement){
    let selectedCurrency:string = currency.value;
    let selectedConversion:string = conversion.value;
    this.navCtrl.push(RatesPage,{selectedCurrency, selectedConversion});
  }
}
