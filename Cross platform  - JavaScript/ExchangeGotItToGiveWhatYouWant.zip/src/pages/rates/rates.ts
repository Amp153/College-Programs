import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ExchangeProvider, ExchangeRate } from '../../providers/exchange/exchange';

/**
 * Generated class for the RatesPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-rates',
  templateUrl: 'rates.html',
})
export class RatesPage {
  currency:string;
  conversion:string;
  myRates:ExchangeRate;

  constructor(public navCtrl: NavController, public navParams: NavParams
    ,public exchangeProvider:ExchangeProvider) {
      this.currency = navParams.get("selectedCurrency");
      this.conversion = navParams.get("selectedConversion");
      this.myRates = new ExchangeRate();
      this.exchangeProvider
        .getExchangeRates(this.currency)
        .subscribe(myRates=>this.myRates = myRates);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad RatesPage');
  }

}
