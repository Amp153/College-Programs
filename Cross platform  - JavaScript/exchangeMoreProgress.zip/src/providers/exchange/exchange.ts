import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Input } from '@angular/core';

/*
  Generated class for the ExchangeProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class ExchangeProvider {

  apibase = "https://api.fixer.io";
  @Input()base:Base;

  constructor(public http: HttpClient) {
    this.base = new Base("USD");
  }
  /*getRates(){
    //console.log(JSON.stringify(this.base));
    return this.http.get(this.apibase + "/latest?base=" + this.base);
  }*/
  getRates(){
    console.log(this.base.baseCurrency);
    return this.http.get(this.apibase + "/latest?base=" + this.base.baseCurrency);
  }
}
/*
base currency that everything is checked against
date year-month-day
rates array of currencies/value pairs based off of the base currency
*/
export class Base{
  baseCurrency:string;

  constructor(baseCurrency:string){
    this.baseCurrency = baseCurrency;
    console.log("Base " + this.baseCurrency);
  }
}
