import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ExchangeProvider, Base } from './../../providers/exchange/exchange';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  rates;
  base:Base;

  constructor(public navCtrl: NavController, public exchange:ExchangeProvider) {
    //this.exchange.getRates().subscribe(rates=>this.rates=JSON.stringify(rates));
  }

  createQuery(baseInput:HTMLInputElement, dateInput:HTMLInputElement){


    this.base = new Base(baseInput.value);
    console.log(this.base.baseCurrency);
    this.exchange.getRates().subscribe(rates=>this.rates=JSON.stringify(rates));
  }
}
