import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { AutoColumnPage } from '../pages/auto-column/auto-column';
import { SpecifyColumnPage } from '../pages/specify-column/specify-column';
import { OffsetColumnPage } from '../pages/offset-column/offset-column';
import { AlignTopColumnPage } from '../pages/align-top-column/align-top-column';
import { AlignCenterColumnPage } from '../pages/align-center-column/align-center-column';
import { AlignBottomColumnPage } from '../pages/align-bottom-column/align-bottom-column';
import { ButtonsPage } from '../pages/buttons/buttons';
import { ListsPage } from '../pages/lists/lists';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    AutoColumnPage,
    SpecifyColumnPage,
    OffsetColumnPage,
    AlignTopColumnPage,
    AlignCenterColumnPage,
    AlignBottomColumnPage,
    ButtonsPage,
    ListsPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    AutoColumnPage,
    SpecifyColumnPage,
    OffsetColumnPage,
    AlignTopColumnPage,
    AlignCenterColumnPage,
    AlignBottomColumnPage,
    ButtonsPage,
    ListsPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
