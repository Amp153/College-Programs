import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the OffsetColumnPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-offset-column',
  templateUrl: 'offset-column.html',
})
export class OffsetColumnPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad OffsetColumnPage');
  }

  goBack(){
    this.navCtrl.pop();
    //this.navCtrl.popAll(); go back to home page
  }
}
