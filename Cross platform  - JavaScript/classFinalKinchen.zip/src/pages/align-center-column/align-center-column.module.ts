import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AlignCenterColumnPage } from './align-center-column';

@NgModule({
  declarations: [
    AlignCenterColumnPage,
  ],
  imports: [
    IonicPageModule.forChild(AlignCenterColumnPage),
  ],
})
export class AlignCenterColumnPageModule {}
