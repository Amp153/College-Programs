import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AlignBottomColumnPage } from './align-bottom-column';

@NgModule({
  declarations: [
    AlignBottomColumnPage,
  ],
  imports: [
    IonicPageModule.forChild(AlignBottomColumnPage),
  ],
})
export class AlignBottomColumnPageModule {}
