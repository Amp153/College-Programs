import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AlignTopColumnPage } from './align-top-column';

@NgModule({
  declarations: [
    AlignTopColumnPage,
  ],
  imports: [
    IonicPageModule.forChild(AlignTopColumnPage),
  ],
})
export class AlignTopColumnPageModule {}
