import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { AutoColumnPage } from '../auto-column/auto-column';
import { SpecifyColumnPage } from '../specify-column/specify-column';
import { OffsetColumnPage } from '../offset-column/offset-column';
import { AlignTopColumnPage } from '../align-top-column/align-top-column';
import { AlignCenterColumnPage } from '../align-center-column/align-center-column';
import { AlignBottomColumnPage } from '../align-bottom-column/align-bottom-column';
import { ButtonsPage } from '../buttons/buttons';
import { ListsPage } from '../lists/lists';
//Anthony Fuller

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController) {

  }

  goTo(pageName){
    switch(pageName){
      case "autoColumn":
        this.navCtrl.push(AutoColumnPage);
        break;
      case "specifyColumn":
        this.navCtrl.push(SpecifyColumnPage);
        break;
      case "offsetColumn":
        this.navCtrl.push(OffsetColumnPage);
        break;
      case "alignTopColumn":
        this.navCtrl.push(AlignTopColumnPage);
        break;
      case "alignCenterColumn":
        this.navCtrl.push(AlignCenterColumnPage);
        break;
      case "alignBottomColumn":
        this.navCtrl.push(AlignBottomColumnPage);
        break;
      case "buttons":
        this.navCtrl.push(ButtonsPage);
        break;
       case "lists":
        this.navCtrl.push(ListsPage);
        break;
    }

  }

}
