import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SpecifyColumnPage } from './specify-column';

@NgModule({
  declarations: [
    SpecifyColumnPage,
  ],
  imports: [
    IonicPageModule.forChild(SpecifyColumnPage),
  ],
})
export class SpecifyColumnPageModule {}
