import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/forkJoin';

@Injectable()
export class ApiProvider {
  private apiBase = "http://api-lite.ga";
  constructor(public http: HttpClient) {}
  /* This will iterate over an object with
  arbitray keys and create an instance of the class Beast */
  //Being thrown the type value from home.ts returns an observable
  //of TypesResponse
  public getByType(type:string):Observable<TypesResponse>{
    //example: http://api-lite.ga/types/air
    //return the response from the url
    return this.http.get(this.apiBase + "/types/" + type)
      .map((response)=>{
        //get each name given from the array, cycle through each one,
        //response is now an array
        Object.keys(response).forEach((key)=>{
          //plainObj has all of the values of beast each beast for
          //that key
          let plainObj = response[key];
          //the response array is now assigned a value for that key
          response[key] = new Beast(plainObj.id,plainObj.location);
        });
        //return a TypesResponse object so no-one is confused
        return response as TypesResponse;
      });
  }
  /* This will punt and say that the object has instances of Beast class
  as it's values */
  public getBySimpleType(type:string):Observable<TypesResponse>{
    return this.http.get(this.apiBase + "/types/" + type)
      .map((response: TypesResponse)=>response);
  }

  //get /diet/:beastid
  public getDietForBeast(beastId):Observable<Array<Food>>{
    return this.http.get(this.apiBase + "/diet/" + beastId) as Observable<Array<Food>>;
  }
  public getFoodInfo(foodName:string):Observable<FoodInfo>{
    let foodObservable = this.http.get(this.apiBase + "/food/" + foodName) as Observable<FoodResponse>;
    let foodImageObservable = this.http.get(this.apiBase + "/foodimage/" + foodName) as Observable<FoodImageResponse>;

    return Observable.forkJoin(foodObservable,foodImageObservable)
            .map((responses)=> new FoodInfo(responses[0].about,responses[1].img));
  }
}
export class FoodInfo{
  constructor(public about:string,public img:string){}
}
interface FoodResponse{
  about:string;
}
interface FoodImageResponse{
  img:string;
}


//{"HungarianHorntail":{"id":0,"location":"Hungary"},
//"GoldenSnidget":{"id":1,"location":"England"}}

//Allows the getByType method to return an observable of TypesResponse
export interface TypesResponse{
  //returns the name of the beast and gets the rest from class Beast
  //turns key into an anonyomous array
  [key:string]:Beast
}
//Everything else that is returned from TypesResponse
export class Beast{
  //everything has an id and a location
  constructor(public id:number,
              public location:string){
  }
}
export class Food{
  name:string;
  img:string;
}
