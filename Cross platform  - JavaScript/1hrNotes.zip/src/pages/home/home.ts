import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ApiProvider, TypesResponse, Beast } from '../../providers/api/api';
import { DietPage } from '../diet/diet';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  beasts:TypesResponse = {};
  constructor(public navCtrl: NavController,
              public apiProvider:ApiProvider) {}
  //being given the value passed from home.html
  loadBeasts(type:string){
    //throw the type value to the getByType method in the api.ts and
    //gets it as in a JSON format
    this.apiProvider.getByType(type).subscribe(obj=>this.beasts=obj);
  }
  showDiet(beast:Beast){
    this.navCtrl.push(DietPage,{id:beast.id});
  }
}
