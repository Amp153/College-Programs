import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AboutFoodPage } from './about-food';

@NgModule({
  declarations: [
    AboutFoodPage,
  ],
  imports: [
    IonicPageModule.forChild(AboutFoodPage),
  ],
})
export class AboutFoodPageModule {}
