import { ApiProvider, FoodInfo } from './../../providers/api/api';
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the AboutFoodPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-about-food',
  templateUrl: 'about-food.html',
})
export class AboutFoodPage {
  foodName:string;
  foodInfo:FoodInfo = {about:"",img:""}
  constructor(public navCtrl: NavController, public navParams: NavParams,
              public apiProvider:ApiProvider) {
    this.foodName = navParams.get("foodName");
    this.apiProvider.getFoodInfo(this.foodName).subscribe((foodInfo)=>this.foodInfo = foodInfo);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AboutFoodPage');
  }

}
