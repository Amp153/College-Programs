import { SomeThingProvider, Geometry } from './../../providers/some-thing/some-thing';
import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  geometry:Array<Geometry>
  constructor(public navCtrl: NavController, provider:SomeThingProvider) {
    //No manipulation of data after you retrieve it from provider
    provider.getAllGeometry().subscribe((geometry)=>this.geometry=geometry);
  }

  addGeometry(geom:Geometry){
    this.geometry.push(geom);
  }
}
