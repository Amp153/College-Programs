import { Component, Input } from '@angular/core';
import { Geometry } from '../../providers/some-thing/some-thing';

@Component({
  selector: 'geometry',
  templateUrl: 'geometry.html'
})
export class GeometryComponent {

  @Input() geom:Geometry;

}
