import { IonicModule } from 'ionic-angular';
import { NgModule } from '@angular/core';
import { GeometryMakerComponent } from './geometry-maker/geometry-maker';
import { CommonModule } from '@angular/common/src/common_module';
import { GeometryListComponent } from './geometry-list/geometry-list';
import { GeometryComponent } from './geometry/geometry';
@NgModule({
	declarations: [GeometryMakerComponent,
    GeometryListComponent,
    GeometryComponent],
	imports: [IonicModule, CommonModule], //ionic componenets or angular directives
	exports: [GeometryMakerComponent,
    GeometryListComponent,
    GeometryComponent]
})
export class ComponentsModule {}
