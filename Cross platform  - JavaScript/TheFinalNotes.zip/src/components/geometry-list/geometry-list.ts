import { Component, Input, Output,EventEmitter } from '@angular/core';
import { Geometry } from '../../providers/some-thing/some-thing';


@Component({
  selector: 'geometry-list',
  templateUrl: 'geometry-list.html'
})
export class GeometryListComponent {

  @Input() geometry:Array<Geometry>;
  @Output() selected = new EventEmitter<Geometry>();
  picked(geom:Geometry){
    this.selected.emit(geom);
  }

}
