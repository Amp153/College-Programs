import { Component, Output, EventEmitter } from '@angular/core';
import { Geometry } from '../../providers/some-thing/some-thing';

/**
 * Generated class for the GeometryMakerComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'geometry-maker',
  templateUrl: 'geometry-maker.html'
})
export class GeometryMakerComponent {
  @Output() created = new EventEmitter<Geometry>();

  createGeometry(lengthInput:HTMLInputElement,widthInput:HTMLInputElement):void{
    const length = parseInt(lengthInput.value);
    const width = parseInt(widthInput.value);
    const geometry = new Geometry(length,width);
    this.created.emit(geometry);
  }
}
