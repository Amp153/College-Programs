import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/from';

/*
  Generated class for the SomeThingProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class SomeThingProvider {

  constructor() {}
  public getAllGeometry():Observable<Array<Geometry>>{
    return Observable.from([
      [new Geometry(15,6),new Geometry(5,16),new Geometry(2,18),new Geometry(3,9),]
    ]);
  }

}

export class Geometry{
  constructor(private length:number, private width:number){}

    get area(){
      return this.length * this.width;
  }
}
