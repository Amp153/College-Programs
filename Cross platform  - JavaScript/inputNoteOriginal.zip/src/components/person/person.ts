import { Component } from '@angular/core';
import { Input } from '@angular/core';

/**
 * Generated class for the PersonComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'person',
  templateUrl: 'person.html'
})
export class PersonComponent {

  @Input()person:Person;
  //@Input()childVariable:string;

  constructor() {

  }

}

export class Person{
  firstName:string;
  lastName:string;
  constructor(firstName:string,lastName:string){
    this.firstName = firstName;
    this.lastName = lastName;
  }
}
