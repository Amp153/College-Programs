import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Person } from '../../components/person/person'

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  person:Person;
  bill:Person;
  //parentVariable:string;

  constructor(public navCtrl: NavController) {
    this.person = new Person('asd ' , 'asd');
    this.bill = new Person('bill','smith');
    //this.parentVariable = 'this value';
  }

}
