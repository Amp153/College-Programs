import { Component, Input } from '@angular/core';
import { TypeResponse } from '../../providers/api/api';


@Component({
  selector: 'beast-list',
  templateUrl: 'beast-list.html'
})
export class BeastListComponent {
  @Input() beasts:TypeResponse;
  constructor() {}

  objectKeys(obj:any){
    return Object.keys(obj);
  }
}
