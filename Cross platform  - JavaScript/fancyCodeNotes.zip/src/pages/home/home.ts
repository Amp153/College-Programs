import { GhibliProvider } from './../../providers/ghibli/ghibli';
import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  data:any;
  constructor(public navCtrl: NavController, private api:GhibliProvider) {
    api.filmsWithPeople().subscribe((data)=>this.data=data);
  }

}
