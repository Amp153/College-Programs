import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { switchMap } from 'rxjs/operators/switchMap';
import { from } from 'rxjs/observable/from';
import { concatMap } from 'rxjs/operators/concatMap';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { map } from 'rxjs/operators/map';

@Injectable()
export class GhibliProvider {
  private apiBase = "https://ghibliapi.herokuapp.com";
  constructor(public http: HttpClient) {}

  filmsWithPeople(){
    return this.http.get(`${this.apiBase}/films`)
    .pipe(
      //returns the last movie
      switchMap((movies:Object[])=>from(movies)),
      //returns a single movie people are a url//returns the people in that movie
      concatMap((movie:any)=>forkJoin(from([movie]), this.http.get(movie.people[0]))),
      //merging the people and movie objects
      //replace {title:movie.title} with just movie to get everything you normally would
      map(([movie,people])=>Object.assign({},{title:movie.title},{people:this.extractName(people)}))
    );
  }

  extractName(people){
    return (people.length > -1)? people.map(person=>person.name):[people.name];
  }

}
