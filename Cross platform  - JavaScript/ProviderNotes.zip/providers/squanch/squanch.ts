//import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class SquanchProvider {
  giveSquanch():Squanch{
    let squanch:Squanch = new Squanch();
    squanch.isYouSquanch = Squanch.TRU;
    return squanch;
  }
}
export class Squanch{
  static TRU:boolean = true;
  isYouSquanch:boolean;

  squanchYeah():boolean{
    return this.isYouSquanch;
  }
}
