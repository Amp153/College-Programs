//import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
//import { Person } from '../../components/person/person';

@Injectable()
export class PersonProvider {

  loadPerson(firstName:string,lastName:string):Person{
    return new Person(firstName,lastName);
  }

}
export class Person{
  firstName:string;
  lastName:string;
  constructor(firstName:string,lastName:string){
    this.firstName = firstName;
    this.lastName = lastName;
  }

  get fullName(){
    return `${this.firstName} ${this.lastName}`;
  }

  set fullName(fullName:string){
    let nameBits = fullName.split(" ");
    this.firstName = nameBits[0];
    this.lastName = nameBits[1];
  }
}
