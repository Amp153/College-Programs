import { Component, Input } from '@angular/core';
import{ Squanch } from '../../providers/squanch/squanch';


@Component({
  selector: 'squanch',
  templateUrl: 'squanch.html'
})
export class SquanchComponent {

  @Input()squanch:Squanch;


}

