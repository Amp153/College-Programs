import { Component } from '@angular/core';

/**
 * Generated class for the TemplatesComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'templates',
  templateUrl: 'templates.html'
})
export class TemplatesComponent {

  text: string;

  constructor() {
    console.log('Hello TemplatesComponent Component');
    this.text = 'Hello World';
  }
  helloEvents(){
    this.text = "Hello from helloEvents()!";
  }
  helloScroll(){
    this.text += "<br /> Hello Scroll";
  }
  setTextToName(name:HTMLInputElement){
    this.text = name.value;
  }

}
