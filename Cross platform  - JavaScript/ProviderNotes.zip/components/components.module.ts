import { NgModule } from '@angular/core';
import { PersonComponent } from './person/person';
import { CommonModule } from '@angular/common';
import { SquanchComponent } from './squanch/squanch';
import { TemplatesComponent } from './templates/templates';
@NgModule({
	declarations: [PersonComponent,
    SquanchComponent,
    TemplatesComponent],
	imports: [CommonModule],
	exports: [PersonComponent,
    SquanchComponent,
    TemplatesComponent]
})
export class ComponentsModule {}
