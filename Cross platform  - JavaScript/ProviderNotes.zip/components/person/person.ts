import { Component,Input } from '@angular/core';
import {Person } from '../../providers/person/person';

/**
 * Generated class for the PersonComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'person',
  templateUrl: 'person.html'
})
export class PersonComponent {

  @Input()person:Person;

 /* constructor() {
    this.person = new Person("Anthony","Fuller");
  }*/

}
