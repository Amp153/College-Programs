import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

import { Person} from'../../providers/person/person';
import { PersonProvider} from '../../providers/person/person';
import {Squanch,SquanchProvider} from '../../providers/squanch/squanch';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
person:Person;
dataFromPersonProvider:string;
squanch:Squanch;
  constructor(public navCtrl: NavController, public personProvider:PersonProvider,public squanchProvider:SquanchProvider) {
    this.person = personProvider.loadPerson("Anthony","Fuller");
    this.squanch = this.squanchProvider.giveSquanch();
  }

}
