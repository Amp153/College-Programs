import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Person } from '../../components/person/person';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  person:Person;
  bill:Person;
  parentComponentClassVariable:string;
  resultFromListen:string;

  constructor(public navCtrl: NavController) {
    this.person = new Person("Austin","Allman");
    this.bill = new Person("Bill","Smith");
    this.parentComponentClassVariable =
    "This value is form the parent component getting passed into the child component";
  }
  parentEventListener($event:string){
    //alert("Parent component listend event$event =" + $event);
    this.resultFromListen = "Parent component listend event$event =" + $event;
  }

}
