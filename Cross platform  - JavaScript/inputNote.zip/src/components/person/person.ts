import { Component, Input } from '@angular/core';

@Component({
  selector: 'person',
  templateUrl: 'person.html'
})
export class PersonComponent {
  @Input()person:Person;
  constructor() {}
}
export class Person{
  firstName:string;
  lastName:string;
  constructor(firstName:string,lastName:string){
    this.firstName = firstName;
    this.lastName = lastName;
  }
}
