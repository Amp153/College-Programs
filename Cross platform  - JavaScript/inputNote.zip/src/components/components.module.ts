import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PersonComponent } from './person/person';
import { ChildComponent } from './child/child';
@NgModule({
	declarations: [PersonComponent,
    ChildComponent],
	imports: [CommonModule],
	exports: [PersonComponent,
    ChildComponent]
})
export class ComponentsModule {}
