<br />
<br />
<p>This is a survey that will send an email of your responses to my email address</p>
<a href = "web_survey.php"> [Test the Script]</a>
<a href = "ShowSourceCode.php?source_file=web_survey.php">[View The Source Code]</a>