<title>Final Project</title>

<p>This script is a calendar</p>
<a href = "EventCalendar.php"> [Test the Script]</a>
<a href = "ShowSourceCode.php?source_file=EventCalendar.php">[View The Source Code]</a>
</br></br></br>