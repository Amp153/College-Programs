
<p><?php include("Includes/inc_connect.php");
			
if($DBConnect === FALSE){
	echo "<p>Cannot find the database!</p>";
}
else{
	//database exists and is connected
	mysqli_select_db($DBConnect,$db_name);
		
	//check for the table
	$db_table = "randomproverb";
	$SQLString = "SHOW TABLES LIKE '$db_table'";
	$QueryResult = @mysqli_query($DBConnect, $SQLString);
	
	if(mysqli_num_rows($QueryResult) == 0){
		//table doesn't exist
		echo "<p>There are no entries in the zodiacfeedback table!</p>";
		
		$QueryResult = @mysqli_query($DBConnect, $SQLString);
	}
	if($QueryResult === False){
		echo "<p>Table issue</p>".
		"<p>Error code: ".mysqli_connect_errno($DBConnect).
		mysqli_connect_error($DBConnect)."</p>";
	}
	else {
		//table exists
		//Display the proverb
		$ProverbCount = mysqli_num_rows($QueryResult);
		echo "<p>A randomly displayed chinese proverb retrieved from a table.</p>";
		$NewProverb = rand(0, $ProverbCount - 1);
		$Array = mysqli_fetch_row($QueryResult);
		echo "<p> $Array[$NewProverb] </p>";	
	
		//Update the display_count
		SQLString = "UPDATE randomproverb SET display_count ".
			" = display_count + 1 WHERE proverb = ".
			$ProverbArray;
		
		$QueryResult = @mysqli_query($DBConnect, $SQLString);
	}//Check if query was successfull
	if($QueryResult === False){
		echo "<p>Query was unable to execute</p>".
		"<p>Error code: ".mysqli_connect_errno($DBConnect).
		mysqli_connect_error($DBConnect)."</p>";
	}
	mysqli_free_result($QueryResult);
	mysqli_close($DBConnect);
}
?></p>
			
<p><?php 

	$DragonArray = array('Images/Dragon1.png',
	'Images/Dragon2.png','Images/Dragon3.png',
	'Images/Dragon4.png','Images/Dragon5.png');
	
	shuffle($DragonArray);
	echo '<img src='.$DragonArray[0].' />';

?></p>
<!-- Copyright and Date -->
<p>&copy; <?php echo date("Y") ?></p>