<img class="banner" src="Images/ChineseZodiacBanner.png"
alt="[Chinese Zodiac Banner]" title="Chinese Zodiac Banner" />