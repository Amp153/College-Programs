<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0
Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- Anthony Fuller -->
<head>
<title>Chinese Zodiac</title>
<meta http-equiv="content-type"
	content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php include("Includes/inc_header.php"); ?>
 
 <table border='1'>
<tr>
<th>Placeholder</th>
<th>Placeholder</th>
<th>Placeholder</th>
</tr>
<?php include("Includes/inc_button_nav.php"); ?>

<?php include("Includes/inc_text_links.php"); ?>

 </table>
 
<?php include("Includes/inc_home.php"); ?>
 
<?php include("Includes/inc_footer.php"); ?>
</body>
</html>