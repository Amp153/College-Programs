<?php include("home_links_bar.inc"); ?>
<p>PHP is an embedded language that is relatively easy to learn
 allowing new programmers to incorporate functionality into a website.
PHP is also a dynamic, growing language with new functionality add on a regular basis.</p>
