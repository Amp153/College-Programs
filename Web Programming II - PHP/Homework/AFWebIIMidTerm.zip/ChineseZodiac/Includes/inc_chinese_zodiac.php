<?php include("inc_home_links_bars.php"); ?>

<p>The Chinese Zodiac, known as Sheng Xiao,
 is based on a twelve-year cycle, 
 each year in that cycle related to an animal sign.
 These signs are the rat, ox, tiger, rabbit, dragon,
 snake, horse, sheep, monkey, rooster, dog and pig.
 It is calculated according to Chinese lunar calendar. </p>
 </br>
 <p>There has been a relationship between human and the 12 zodiacal animals. 
 It is believed that the years represented by the animals affect the characters 
 of people in the same way like the western astrology signs.</p>
</br>
 <p>Similar to the ten heavenly stems and twelve earthly branches, 
 animals in Chinese zodiac were also created for counting years as 
 the system that is now universally accepted based on the Gregorian calendar. 
 The selection and order of the animals that influence people's lives very much was originated
 in the Han Dynasty (202BC ? 220AD) and based upon each animal's character and living habits. 
 The old-time division was mostly related to number 12: one ji equals 12 years, one year has 12 months,
 one day has 12 time periods called shi chen. Ancient people observe that there are 12 full moons within one year.
 So, its origin is associated with astrology. Each animal sign is usually related with an earthly branch, 
 so the animal years were called Zi Rat, Chou Ox, Yin Tiger, Mao Rabbit, Chen Dragon,
 Si Snake, Wu Horse, Wei Sheep, Shen Monkey, You Rooster, Xu Dog and Hai Pig.</p>
