<p>This is the difference between dynamic and static content 
and I'm illustrating the syntax for targeting content to a dynamic content section</p>