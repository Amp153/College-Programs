
<p><? //reads from the file
			$File = fopen("proverbs.txt", 'rb');
			$Count = fgets($File);
			$Array = explode("\\", $Count);
			$ProverbCount = count($Array);
			echo "<p>A randomly displayed chinese proverb read from a text file.</p>";
			$NewProverb = rand(0, $ProverbCount - 1);
			echo "<p> $Array[$NewProverb] </p>";
			fclose($File);
			?></p>
			
<!-- Copyright and Date -->
<p>&copy; <?php echo date("Y") ?></p>