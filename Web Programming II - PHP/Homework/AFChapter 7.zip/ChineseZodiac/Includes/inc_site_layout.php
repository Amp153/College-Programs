<p>Static content never changes while Dynamic content changes depending on 
what is sent to the server.</p>