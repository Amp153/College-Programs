<p>User input gets sent to the web page as a string.</p>
<p>A basic web page consists of a header, body, and a footer.</p>

<!-- Text Navigation bar -->
<a href = "#sort">Alphabetizing user input</a>
<a href = "#gallery">Zodiac Gallery</a>
<!-- End of Text Navigation bar -->

<a id = "sort">Alphabetizing user input</a>
<p>This script takes each sign entered, sorts the array of signs and displays them.</p>
<a href = "AlphabetizeSigns.php"> [Test the Script]</a>

<a href = "ShowSourceCode.php?source_file=AlphabetizeSigns.php">[View The Source Code]</a>

<a id = "gallery">Zodiac Gallery</a>
<p>This script takes each image and displays them.</p>
<a href = "ZodiacGallery.php"> [Test the Script]</a>

<a href = "ShowSourceCode.php?source_file=ZodiacGallery.php">[View The Source Code]</a>