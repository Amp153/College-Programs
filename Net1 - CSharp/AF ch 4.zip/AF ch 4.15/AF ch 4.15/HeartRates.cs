﻿using System;
//Anthony Fuller

namespace AF_ch_4._15
{
    class HeartRates
    {
            // Using year of birth because having a date would 
            // make everything really complicated
            
            public string FirstN { get; set; }
            public string LastN { get; set; }
            


            private string firstN;
            private string lastN;
            private string yoB;
            private int currentYear;
            int age;
            double heartRate;
            double minHeartRate;
            double maxHeartRate;

            public HeartRates(){
            
            }
            

            public HeartRates(string firstName, string lastName, string yearOfBirth, string year){
                FirstN = firstName;
                LastN = lastName;
                YoB = yearOfBirth;
                CurrentYear = year;
                age = currentYear - Int32.Parse(yoB);
                heartRate = 220.0 - age;
                minHeartRate = heartRate * .5;
                maxHeartRate = heartRate * .85;
            }


        public string YoB{
            set{
            if ( Int32.Parse(yoB) < currentYear)
                yoB = value;
            }
            get{
            return yoB;
            }
        }
        public string CurrentYear{
            set{
                currentYear = Int32.Parse(value);
            }
            get{
            return currentYear.ToString();
            }

        public int GetAge(){
            return age;
        }
        public double GetHeartRate(){
            return heartRate;
        }
        public double MaxHeartRate(){
            return maxHeartRate;
        }
        public double MinHeartRate(){
            return minHeartRate;
        }
        }
    }
}
