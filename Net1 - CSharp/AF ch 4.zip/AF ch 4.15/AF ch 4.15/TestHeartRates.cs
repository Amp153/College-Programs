﻿using System;
//Anthony Fuller

namespace AF_ch_4._15
{
    class TestHeartRates
    {
        static void Main(string[] args)
        {
            HeartRates heart1 = new HeartRates();

            // prompt for info
            Console.WriteLine("Enter your first name: ");
            heart1.FirstN = Console.ReadLine();
            Console.WriteLine("Enter your last name: ");
            heart1.LastN = Console.ReadLine();
            Console.WriteLine("Enter your year of birth: ");
            heart1.YoB = Console.ReadLine();
            Console.WriteLine("Enter the current year: ");
            heart1.CurrentYear = Console.ReadLine();
            
            // return info
            Console.WriteLine("First name: " + heart1.FirstN);
            Console.WriteLine("Last name: " + heart1.LastN);
            Console.WriteLine("Year of birth: " + heart1.YoB);
            Console.WriteLine("The current year: " + heart1.CurrentYear);


            Console.WriteLine("You are "+ heart1.GetAge() + "years old");
            Console.WriteLine("Your maximum heart rate for your age is: " + heart1.GetHeartRate());
            Console.WriteLine("Your maximum target heart rate is: " + heart1.MaxHeartRate());
            Console.WriteLine("Your minimum target heart rate is: " + heart1.MinHeartRate());
        }
    }
}
