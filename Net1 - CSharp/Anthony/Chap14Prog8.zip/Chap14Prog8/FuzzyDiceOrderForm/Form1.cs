﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FuzzyDiceOrderForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        

        

        private void btnNew_Click(object sender, EventArgs e)
        {
            Random randomNum = new Random();
            int guessMe = randomNum.Next(1,1001);
            //Form1.BackColor = Form1.DefaultBackColor;
            lblGuessMe.Text = guessMe.ToString();
            txtNum.Enabled = true;
            this.BackColor = DefaultBackColor;
            lblFirst.Text = "Please enter your first guess";
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(lblHelper.Text) != 0)
                lblFirst.Text = "";
            
            //The number the user needs to guess
            int ranNum = Convert.ToInt32(lblGuessMe.Text);
            
            int guessedNum = 0;
            
            
                //The number the user guesses
                guessedNum = Convert.ToInt32((txtNum.Text).ToString());
            
            int num3 = 0;

            int num2 = Math.Abs(ranNum - guessedNum);
            if (num2 != Convert.ToInt32((lblHelper.Text).ToString()))
            {
            num3 = Convert.ToInt32((lblHelper.Text).ToString());
            }
            if (num2 == 0)
            {
                this.BackColor = Color.Green;
                lblHelper.Text = num2.ToString();
            }
            else if (num2 < num3 && Convert.ToInt32(lblHelper.Text) != 0)
            {
                this.BackColor = Color.Red;
                lblHelper.Text = num2.ToString();
            }
            else if (num2 > num3 && Convert.ToInt32(lblHelper.Text) != 0)
            {
                this.BackColor = Color.Blue;
                lblHelper.Text = num2.ToString();
            }
            else
            {
                this.BackColor = DefaultBackColor;
                lblHelper.Text = num2.ToString();
            }

            if (guessedNum < ranNum && guessedNum != 0)
            {
                lblHint.Text = "Too low";
            }
            else if (guessedNum > ranNum)
            {
                lblHint.Text = "Too high";
            }
            else
            {
                lblHint.Text = "Correct!";
                txtNum.Enabled = false;
            }
        }

        

        

       
    }
}
